"""Pydantic schemas for personnel orders read API (WP-PO-004A)."""
from __future__ import annotations

from datetime import date
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, model_validator


class PersonnelOrderHeaderOut(BaseModel):
    order_id: int
    order_number: Optional[str] = None
    order_date: Optional[str] = None
    order_type_code: str
    order_class: str
    status: str
    document_revision: int = 1
    source_title: Optional[str] = None
    source_title_locale: Optional[Literal["kk", "ru", "unknown"]] = None
    source_mode: str
    legal_basis_article: Optional[str] = None
    signed_by_employee_id: Optional[int] = None
    signed_by_name: Optional[str] = None
    signed_by_position: Optional[str] = None
    executor_name: Optional[str] = None
    basis_summary: Optional[str] = None
    storage_json: Dict[str, Any] = Field(default_factory=dict)
    comment: Optional[str] = None
    void_reason: Optional[str] = None
    voided_at: Optional[str] = None
    voided_by: Optional[int] = None
    created_by: int
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    is_archived: bool = False
    archive_summary_at: Optional[str] = None
    archive_summary_by_name: Optional[str] = None
    archive_summary_reason: Optional[str] = None


class PersonnelOrderListItemOut(PersonnelOrderHeaderOut):
    item_count: int = 0
    employee_ids: List[int] = Field(default_factory=list)
    employee_names: List[str] = Field(default_factory=list)


class PersonnelOrderListResponse(BaseModel):
    items: List[PersonnelOrderListItemOut]
    total: int
    limit: int
    offset: int


class PersonnelOrderItemOut(BaseModel):
    item_id: int
    order_id: int
    item_number: int
    item_type_code: str
    item_status: str
    employee_id: Optional[int] = None
    employee_name: Optional[str] = None
    org_unit_id: Optional[int] = None
    org_unit_name: Optional[str] = None
    effective_date: Optional[str] = None
    period_start: Optional[str] = None
    period_end: Optional[str] = None
    payload: Dict[str, Any] = Field(default_factory=dict)
    void_reason: Optional[str] = None
    voided_at: Optional[str] = None
    voided_by: Optional[int] = None
    created_at: Optional[str] = None


class PersonnelOrderLocalizedTextOut(BaseModel):
    localized_text_id: int
    order_id: int
    locale: str
    title: Optional[str] = None
    preamble: Optional[str] = None
    body_text: Optional[str] = None
    render_version: int
    is_authoritative: bool
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class PersonnelOrderAttachmentOut(BaseModel):
    attachment_id: int
    order_id: int
    attachment_kind: str
    storage_type: str
    file_path: Optional[str] = None
    file_url: Optional[str] = None
    file_comment: Optional[str] = None
    locale: Optional[str] = None
    created_by: int
    created_at: Optional[str] = None


class PersonnelOrderPrintOut(BaseModel):
    print_id: int
    order_id: int
    locale: str
    format: str
    file_path: Optional[str] = None
    file_url: Optional[str] = None
    is_signed_copy: bool
    render_version: int
    generated_at: Optional[str] = None
    generated_by: Optional[int] = None


class PersonnelOrderLinkedEventOut(BaseModel):
    event_id: int
    order_id: Optional[int] = None
    order_item_id: Optional[int] = None
    employee_id: int
    employee_name: Optional[str] = None
    event_type: str
    event_class: str
    event_label: str
    lifecycle_status: str
    metadata: Optional[Dict[str, Any]] = None
    effective_date: Optional[str] = None
    from_org_unit_id: Optional[int] = None
    from_org_unit_name: Optional[str] = None
    to_org_unit_id: Optional[int] = None
    to_org_unit_name: Optional[str] = None
    from_position_id: Optional[int] = None
    from_position_name: Optional[str] = None
    to_position_id: Optional[int] = None
    to_position_name: Optional[str] = None
    from_rate: Optional[float] = None
    to_rate: Optional[float] = None
    order_ref: Optional[str] = None
    comment: Optional[str] = None
    created_at: Optional[str] = None


class PersonnelOrderDetailResponse(BaseModel):
    order: PersonnelOrderHeaderOut
    items: List[PersonnelOrderItemOut]
    localized_texts: List[PersonnelOrderLocalizedTextOut]
    attachments: List[PersonnelOrderAttachmentOut]
    prints: List[PersonnelOrderPrintOut]
    events: List[PersonnelOrderLinkedEventOut]
    acknowledgements: List["PersonnelOrderAcknowledgementOut"] = Field(default_factory=list)


class PersonnelOrderAcknowledgementOut(BaseModel):
    acknowledgement_event_id: int
    order_id: int
    employee_id: int
    event_type: str
    acknowledged_on: Optional[str] = None
    created_at: Optional[str] = None
    created_by_user_id: int


class PersonnelOrderAcknowledgementListResponse(BaseModel):
    items: List[PersonnelOrderAcknowledgementOut] = Field(default_factory=list)


class PersonnelOrderAcknowledgementRecordIn(BaseModel):
    employee_id: int = Field(..., ge=1)
    acknowledged_on: date


class PersonnelOrderAcknowledgementClearIn(BaseModel):
    employee_id: int = Field(..., ge=1)


class PersonnelOrderSignatoryDefaultOut(BaseModel):
    signed_by_employee_id: Optional[int] = None
    signed_by_name: Optional[str] = None
    signed_by_position: Optional[str] = None
    warning: Optional[str] = None
    source: Optional[str] = None


class PersonnelOrderCreateIn(BaseModel):
    order_number: str = Field(..., min_length=1, max_length=200)
    order_date: date
    order_type_code: str = Field(..., min_length=1, max_length=80)
    source_mode: str = Field(default="DIGITAL", max_length=20)
    legal_basis_article: Optional[str] = Field(default=None, max_length=500)
    signed_by_employee_id: Optional[int] = Field(default=None, ge=1)
    signed_by_name: Optional[str] = Field(default=None, max_length=200)
    signed_by_position: Optional[str] = Field(default=None, max_length=200)
    executor_name: Optional[str] = Field(default=None, max_length=200)
    basis_summary: Optional[str] = Field(default=None, max_length=2000)
    storage_json: Dict[str, Any] = Field(default_factory=dict)
    comment: Optional[str] = Field(default=None, max_length=2000)


class PersonnelOrderUpdateIn(BaseModel):
    model_config = {"extra": "forbid"}

    order_number: Optional[str] = Field(default=None, min_length=1, max_length=200)
    order_date: Optional[date] = None
    order_type_code: Optional[str] = Field(default=None, min_length=1, max_length=80)
    source_mode: Optional[str] = Field(default=None, max_length=20)
    legal_basis_article: Optional[str] = Field(default=None, max_length=500)
    signed_by_employee_id: Optional[int] = Field(default=None, ge=1)
    signed_by_name: Optional[str] = Field(default=None, max_length=200)
    signed_by_position: Optional[str] = Field(default=None, max_length=200)
    executor_name: Optional[str] = Field(default=None, max_length=200)
    basis_summary: Optional[str] = Field(default=None, max_length=2000)
    comment: Optional[str] = Field(default=None, max_length=2000)


class PersonnelOrderItemCreateIn(BaseModel):
    item_type_code: str = Field(..., min_length=1, max_length=80)
    employee_id: Optional[int] = Field(default=None, ge=1)
    effective_date: Optional[date] = None
    period_start: Optional[date] = None
    period_end: Optional[date] = None
    payload: Dict[str, Any] = Field(default_factory=dict)
    item_number: Optional[int] = Field(default=None, ge=1)


class PersonnelOrderItemUpdateIn(BaseModel):
    model_config = {"extra": "forbid"}

    item_type_code: Optional[str] = Field(default=None, min_length=1, max_length=80)
    employee_id: Optional[int] = Field(default=None, ge=1)
    effective_date: Optional[date] = None
    period_start: Optional[date] = None
    period_end: Optional[date] = None
    payload: Optional[Dict[str, Any]] = None
    item_number: Optional[int] = Field(default=None, ge=1)


class PersonnelOrderLocalizedTextUpsertIn(BaseModel):
    title: Optional[str] = Field(default=None, max_length=500)
    preamble: Optional[str] = Field(default=None, max_length=4000)
    body_text: Optional[str] = None
    is_authoritative: Optional[bool] = None


class PersonnelOrderRegisterIn(BaseModel):
    target_status: str = Field(..., min_length=1, max_length=40)


class PersonnelOrderVoidIn(BaseModel):
    void_reason: str = Field(..., min_length=1, max_length=2000)


PersonnelOrderCancelReasonCode = Literal[
    "duplicate",
    "created_by_mistake",
    "no_longer_required",
    "replaced_before_registration",
    "test_record",
    "other",
]


class PersonnelOrderCancelIn(BaseModel):
    reason_code: PersonnelOrderCancelReasonCode
    reason_text: Optional[str] = Field(default=None, max_length=2000)


PersonnelOrderArchiveReasonCode = Literal[
    "completed",
    "voided_record",
    "migrated_legacy",
    "duplicate_reference",
    "other",
]


class PersonnelOrderArchiveIn(BaseModel):
    reason_code: str = Field(..., min_length=1, max_length=80)
    reason_text: Optional[str] = Field(default=None, max_length=2000)


class PersonnelOrderRestoreIn(BaseModel):
    model_config = {"extra": "forbid"}


class EditorialBlockOut(BaseModel):
    block_id: int
    scope: str
    order_item_id: Optional[int] = None
    locale: str
    block_type: str
    generated_text: Optional[str] = None
    override_text: Optional[str] = None
    effective_text: str = ""
    suppressed: bool = False
    generator_key: Optional[str] = None
    generator_version: Optional[str] = None
    source_fingerprint: Optional[str] = None
    review_status: str
    basis_required: Optional[bool] = None
    editable: bool = False
    revision: int = 1
    generated_at: Optional[str] = None
    edited_at: Optional[str] = None
    edited_by_user_id: Optional[int] = None


class EditorialItemGroupOut(BaseModel):
    order_item_id: int
    item_number: int
    item_type_code: str
    basis_required: bool = False
    blocks: List[EditorialBlockOut] = Field(default_factory=list)


class EditorialStateResponse(BaseModel):
    order_id: int
    order_status: str
    editable: bool
    order_blocks: List[EditorialBlockOut] = Field(default_factory=list)
    items: List[EditorialItemGroupOut] = Field(default_factory=list)


class EditorialGenerateIn(BaseModel):
    model_config = {"extra": "forbid"}

    locale: Optional[str] = Field(default=None, max_length=8)
    item_id: Optional[int] = Field(default=None, ge=1)
    block_id: Optional[int] = Field(default=None, ge=1)
    block_type: Optional[str] = Field(default=None, max_length=40)


class EditorialBlockPatchIn(BaseModel):
    model_config = {"extra": "forbid"}

    override_text: Optional[str] = None
    clear_override: bool = False
    expected_revision: Optional[int] = Field(default=None, ge=1)


class PersonnelOrderTemplateApplicationIn(BaseModel):
    expected_document_revision: int = Field(..., ge=1)
    confirm_replace_overrides: bool = False
    confirm_reapply: bool = False


class PersonnelOrderTemplateApplicationPreviewOut(BaseModel):
    available: bool
    template: Dict[str, Any]
    has_overrides: bool
    override_blocks: List[Dict[str, Any]] = Field(default_factory=list)
    has_prior_application: bool
    last_application: Optional[Dict[str, Any]] = None
    # Legacy aliases are supplied for one-item orders only.
    current: Dict[str, Dict[str, Any]] = Field(default_factory=dict)
    proposed: Dict[str, str] = Field(default_factory=dict)
    order_current: Dict[str, Dict[str, Any]] = Field(default_factory=dict)
    order_proposed: Dict[str, str] = Field(default_factory=dict)
    items: List[Dict[str, Any]] = Field(default_factory=list)
    order_revision: int


PersonnelOrderVoidKind = Literal["CANCEL", "ANNUL"]
PersonnelOrderLifecycleAuditAction = Literal[
    "CANCEL",
    "ANNUL",
    "ARCHIVE",
    "RESTORE",
    "VOID_APPLIED",
    "HARD_DELETE",
    "COMPENSATE_LINK",
    "DOCUMENT_CONFIRMED",
    "DOCUMENT_REOPENED",
    "HEADER_UPDATED",
    "ITEM_UPDATED",
]


class PersonnelOrderLifecycleAuditOut(BaseModel):
    id: int
    order_id: int
    action: PersonnelOrderLifecycleAuditAction
    previous_status: Optional[str] = None
    new_status: Optional[str] = None
    previous_void_kind: Optional[PersonnelOrderVoidKind] = None
    new_void_kind: Optional[PersonnelOrderVoidKind] = None
    actor_user_id: int
    reason_code: Optional[str] = None
    reason_text: Optional[str] = None
    metadata_json: Dict[str, Any] = Field(default_factory=dict)
    created_at: Optional[str] = None


class PersonnelOrderLifecycleAuditListResponse(BaseModel):
    items: List[PersonnelOrderLifecycleAuditOut]
    total: int
    limit: int
    offset: int


PersonnelOrderDocumentReviewState = Literal["NEEDS_REVIEW", "CONFIRMED"]


class PersonnelOrderDocumentReviewOut(BaseModel):
    state: PersonnelOrderDocumentReviewState
    document_revision: int = Field(ge=1)
    confirmed_at: Optional[str] = None
    confirmed_by: Optional[int] = None
    latest_reason_code: Optional[str] = None
    latest_note: Optional[str] = None
    blockers: List[Dict[str, Any]] = Field(default_factory=list)
    warnings: List[Dict[str, Any]] = Field(default_factory=list)
    allowed_actions: List[str] = Field(default_factory=list)


class PersonnelOrderDocumentReviewConfirmIn(BaseModel):
    model_config = {"extra": "forbid"}
    expected_document_revision: int = Field(..., ge=1)
    reason_code: str = Field(..., min_length=1, max_length=80)
    note: Optional[str] = Field(default=None, max_length=2000)


class PersonnelOrderDocumentReviewReopenIn(BaseModel):
    model_config = {"extra": "forbid"}
    expected_document_revision: int = Field(..., ge=1)
    reason_code: str = Field(..., min_length=1, max_length=80)
    note: str = Field(..., min_length=1, max_length=2000)

class PersonnelOrderHeaderDuplicatePreviewIn(BaseModel):
    model_config = {"extra": "forbid"}
    order_id: Optional[int] = Field(default=None, ge=1)
    order_number: str = Field(..., min_length=1, max_length=200)
    order_date: Optional[date] = None

class PersonnelOrderDocumentHeaderPatchIn(PersonnelOrderHeaderDuplicatePreviewIn):
    expected_document_revision: int = Field(..., ge=1)
    source_title: Optional[str] = Field(default=None, max_length=2000)
    source_title_locale: Optional[Literal["kk", "ru", "unknown"]] = None
    reason_code: Optional[str] = Field(default=None, max_length=80)
    reason_text: Optional[str] = Field(default=None, max_length=2000)


class PersonnelOrderDocumentSubjectContextIn(BaseModel):
    """Document-only overrides for a selected employee; never an assignment mutation."""

    model_config = {"extra": "forbid"}
    org_unit_name: Optional[str] = Field(default=None, max_length=300)
    position_name: Optional[str] = Field(default=None, max_length=300)
    specialty: Optional[str] = Field(default=None, max_length=300)
    rate: Optional[str] = Field(default=None, max_length=40)
    recall_position_kk: Optional[str] = Field(default=None, max_length=300)
    recall_org_unit_kk: Optional[str] = Field(default=None, max_length=300)
    basis_ru: Optional[str] = Field(default=None, max_length=2000)
    basis_kk: Optional[str] = Field(default=None, max_length=2000)
    basis_type: Optional[Literal["PERSONAL_APPLICATION", "OTHER"]] = None


class PersonnelOrderDocumentItemPatchIn(BaseModel):
    model_config = {"extra": "forbid"}
    expected_document_revision: int = Field(..., ge=1)
    item_type_code: str = Field(..., min_length=1, max_length=80)
    employee_id: Optional[int] = Field(default=None, ge=1)
    effective_date: Optional[date] = None
    document_subject_context: Optional[PersonnelOrderDocumentSubjectContextIn] = None
    reason_code: Optional[str] = Field(default=None, max_length=80)
    reason_text: Optional[str] = Field(default=None, max_length=2000)


class PersonnelOrderDocumentItemOut(BaseModel):
    """Safe document-correction projection; deliberately excludes payload."""
    item_id: int
    item_number: int
    item_type_code: str
    employee_id: Optional[int] = None
    employee_name: Optional[str] = None
    org_unit_name: Optional[str] = None
    position_name: Optional[str] = None
    specialty: Optional[str] = None
    rate: Optional[str] = None
    recall_position_kk: Optional[str] = Field(default=None, max_length=300)
    recall_org_unit_kk: Optional[str] = Field(default=None, max_length=300)
    basis_ru: Optional[str] = Field(default=None, max_length=2000)
    basis_kk: Optional[str] = Field(default=None, max_length=2000)
    needs_employee_link: bool = False
    effective_date: Optional[str] = None


class PersonnelOrderDocumentItemListResponse(BaseModel):
    document_revision: int
    items: List[PersonnelOrderDocumentItemOut]


class PersonnelOrderUnresolvedSubjectIn(BaseModel):
    """Typed, unlinked subject supplied by HR when the employee is not in the directory."""

    model_config = {"extra": "forbid"}
    full_name: str = Field(..., min_length=1, max_length=300)
    org_unit_name: str = Field(..., min_length=1, max_length=300)
    position_name: str = Field(..., min_length=1, max_length=300)
    specialty: str = Field(..., min_length=1, max_length=300)


class PersonnelOrderManualDraftCreateIn(BaseModel):
    model_config = {"extra": "forbid"}
    template_version_id: Optional[int] = Field(default=None, ge=1)
    order_number: str = Field(..., min_length=1, max_length=200)
    order_date: date
    source_title: str = Field(..., min_length=1, max_length=2000)
    source_title_locale: Literal["kk", "ru"]
    item_type_code: str = Field(..., min_length=1, max_length=80)
    employee_id: Optional[int] = Field(default=None, ge=1)
    unresolved_subject: Optional[PersonnelOrderUnresolvedSubjectIn] = None
    document_subject_context: Optional[PersonnelOrderDocumentSubjectContextIn] = None
    effective_date: date
    period_start: Optional[date] = None
    period_end: Optional[date] = None
    item_payload: Optional[Dict[str, Any]] = None

    @model_validator(mode="after")
    def require_exactly_one_subject(self) -> "PersonnelOrderManualDraftCreateIn":
        if (self.employee_id is None) == (self.unresolved_subject is None):
            raise ValueError("Specify either employee_id or unresolved_subject.")
        if self.item_type_code == "LEAVE.UNPAID.GRANT":
            if self.period_start is None or self.period_end is None:
                raise ValueError("Unpaid leave requires period_start and period_end.")
            if self.period_end < self.period_start:
                raise ValueError("period_end must not be earlier than period_start.")
            if self.effective_date != self.period_start:
                raise ValueError("effective_date must equal period_start for unpaid leave.")
        return self


class PersonnelOrderPublishedTemplateTitleOut(BaseModel):
    template_version_id: Optional[int] = None
    item_type_code: str
    title_ru: str
    title_kk: str


class PersonnelOrderManualDraftCreateOut(BaseModel):
    order_id: int
    order_number: str
    order_type_code: str
    status: str
    source_mode: str
    document_revision: int
    document_review_state: Literal["NEEDS_REVIEW"]
