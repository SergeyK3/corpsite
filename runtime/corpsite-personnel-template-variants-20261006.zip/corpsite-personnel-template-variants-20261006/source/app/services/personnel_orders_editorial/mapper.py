"""Editorial payload / serialization helpers (WP-PO-EDIT-002)."""
from __future__ import annotations

import json
from datetime import date, datetime
from typing import Any, Dict, Mapping, Optional


def effective_text(override_text: Optional[str], generated_text: Optional[str]) -> str:
    return (override_text or "").strip() or (generated_text or "").strip()


def iso_datetime(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value)


def iso_date(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    return str(value)


def payload_dict(raw: Any) -> Dict[str, Any]:
    if raw is None:
        return {}
    if isinstance(raw, dict):
        return dict(raw)
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            return dict(parsed) if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            return {}
    return {}


def pick_payload_value(payload: Mapping[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in payload and payload[key] not in (None, ""):
            return payload[key]
    return None


def build_item_ctx(item: Mapping[str, Any], employee_name: Optional[str]) -> Dict[str, Any]:
    payload = payload_dict(item.get("payload"))
    document_forms_kk = payload_dict(payload.get("document_forms_kk"))
    assignment = payload_dict(payload.get("to_assignment") or payload.get("assignment"))
    presentation = payload_dict(payload.get("presentation_context"))
    org_unit_name = pick_payload_value(
        payload, "source_org_unit_name", "org_unit_name", "orgUnitName", "from_org_unit_name"
    ) or presentation.get("org_unit_name") or assignment.get("unit") or item.get("snapshot_org_unit_name")
    position_name = pick_payload_value(
        payload, "source_position_name", "position_name", "positionName", "from_position_name"
    ) or presentation.get("position_name") or assignment.get("position") or item.get("snapshot_position_name")
    leave_start = pick_payload_value(payload, "leave_start")
    leave_end = pick_payload_value(payload, "leave_end")
    leave_days = pick_payload_value(payload, "leave_days")
    leave_period_type = None
    if item.get("item_type_code") == "LEAVE.UNPAID.GRANT":
        # The versioned contract is authoritative for new unpaid-leave items.
        try:
            from app.services.personnel_order_unpaid_leave_contract import unpaid_leave_period

            period = unpaid_leave_period(payload)
            leave_period_type = period["period_type"]
            leave_start = period["start"].isoformat()
            leave_end = period["end"].isoformat()
            leave_days = period["days"]
        except ValueError:
            # Validation owns the user-facing rejection.  The editorial read
            # remains non-destructive for historical malformed payloads.
            pass
    return {
        "item_type_code": item.get("item_type_code"),
        "recall_payload": payload if item.get("item_type_code") == "LEAVE.ANNUAL.RECALL" else None,
        "childcare_payload": payload if item.get("item_type_code") == "LEAVE.CHILDCARE.GRANT" else None,
        "employee_name": employee_name or pick_payload_value(payload, "source_employee_name"),
        "effective_date": iso_date(item.get("effective_date")),
        "org_unit_name": org_unit_name,
        "position_name": position_name,
        # Explicit document forms are authoritative for the Kazakh document;
        # do not try to infer them from a Russian position snapshot.
        "position_document_possessive_kk": pick_payload_value(
            document_forms_kk, "position_document_possessive_kk", "position_possessive", "document_possessive_kk"
        ),
        "to_org_unit_name": pick_payload_value(
            payload, "to_org_unit_name", "toOrgUnitName"
        ) or assignment.get("unit"),
        "to_position_name": pick_payload_value(
            payload, "to_position_name", "toPositionName"
        ) or assignment.get("position"),
        "rate": pick_payload_value(payload, "document_rate", "employment_rate", "rate", "from_rate") or assignment.get("rate"),
        "specialty": pick_payload_value(payload, "document_specialty"),
        "to_rate": pick_payload_value(payload, "to_rate", "toRate", "employment_rate") or assignment.get("rate"),
        "concurrent_rate": pick_payload_value(
            payload, "concurrent_rate", "concurrentRate"
        ),
        "remaining_rate": pick_payload_value(
            payload, "remaining_rate", "remainingRate"
        ),
        "total_rate": pick_payload_value(payload, "total_rate", "totalRate"),
        "termination_reason": pick_payload_value(
            payload, "termination_reason", "terminationReason", "reason"
        ),
        "termination_unused_leave_days": pick_payload_value(
            payload, "termination_unused_leave_days"
        ),
        # Leave data is kept in the item payload. It is deliberately passed
        # through as one structured source for both editorial locales.
        "leave_start": leave_start,
        "leave_end": leave_end,
        "leave_days": leave_days,
        "leave_period_type": leave_period_type,
        "work_periods": payload.get("work_periods"),
        "work_period_start": pick_payload_value(payload, "work_period_start"),
        "work_period_end": pick_payload_value(payload, "work_period_end"),
        "work_period_days": pick_payload_value(payload, "work_period_days"),
        "basis": payload.get("basis"),
        "vacation_benefit_applicable": payload.get("vacation_benefit_applicable"),
        "vacation_benefit_rule": pick_payload_value(payload, "vacation_benefit_rule"),
    }


def serialize_block(
    row: Mapping[str, Any],
    *,
    scope: str,
    editable: bool,
) -> Dict[str, Any]:
    override = row.get("override_text")
    generated = row.get("generated_text")
    suppressed = row.get("block_type") == "closing" and override == ""
    out: Dict[str, Any] = {
        "block_id": int(row["block_id"]),
        "scope": scope,
        "order_item_id": int(row["order_item_id"]) if row.get("order_item_id") is not None else None,
        "locale": row["locale"],
        "block_type": row["block_type"],
        "generated_text": generated,
        "override_text": override,
        "effective_text": "" if suppressed else effective_text(override, generated),
        "suppressed": suppressed,
        "generator_key": row.get("generator_key"),
        "generator_version": row.get("generator_version"),
        "source_fingerprint": row.get("source_fingerprint"),
        "review_status": row["review_status"],
        "basis_required": bool(row["basis_required"]) if row.get("basis_required") is not None else None,
        "editable": editable,
        "revision": int(row.get("revision") or 1),
        "generated_at": iso_datetime(row.get("generated_at")),
        "edited_at": iso_datetime(row.get("edited_at")),
        "edited_by_user_id": (
            int(row["edited_by_user_id"]) if row.get("edited_by_user_id") is not None else None
        ),
    }
    return out
