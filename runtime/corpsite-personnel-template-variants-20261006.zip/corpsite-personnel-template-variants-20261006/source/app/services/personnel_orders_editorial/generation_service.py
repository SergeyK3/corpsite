"""Editorial text generation / regeneration (WP-PO-EDIT-002).

Per-block try/except: a failed block is marked GENERATION_FAILED while
successful blocks in the same generate call are still committed in the same
transaction. Overrides are never cleared on regenerate.
"""
from __future__ import annotations

from contextlib import nullcontext
from typing import Any, Dict, Mapping, Optional

from sqlalchemy.engine import Connection

from app.db.engine import engine
from app.db.models.personnel_orders import (
    ITEM_BLOCK_TYPE_BASIS,
    ITEM_BLOCK_TYPE_BODY,
    ITEM_BLOCK_TYPES,
    ORDER_BLOCK_TYPE_PREAMBLE,
    ORDER_BLOCK_TYPE_TITLE,
    ORDER_BLOCK_TYPES,
    REVIEW_STATUS_GENERATION_FAILED,
    ORDER_TYPE_SUPPLEMENTARY_PAY,
)
from app.services.personnel_orders_editorial.audit import write_editorial_audit
from app.services.personnel_order_archive_guard import assert_order_not_archived
from app.services.personnel_order_evidence_scope_service import (
    advance_personnel_order_evidence_scopes_tx,
    lock_personnel_order_evidence_scopes_tx,
)
from app.services.personnel_orders_editorial.availability import require_available
from app.services.personnel_orders_editorial.basis_policy import resolve_basis_required
from app.services.personnel_orders_editorial.constants import ALLOWED_LOCALES
from app.services.personnel_orders_editorial.fallback import load_legacy_localized
from app.services.personnel_orders_editorial.generators import (
    generate_basis_text,
    generate_item_body,
    generate_order_block,
    generate_supplementary_pay_basis,
)
from app.services.personnel_orders_editorial.mapper import build_item_ctx, iso_date
from app.services.personnel_orders_editorial.repository import (
    ensure_default_basis,
    fetch_order,
    load_bases,
    load_employee_names,
    load_item_blocks,
    load_items,
    load_order_blocks,
    mark_item_block_failed,
    mark_order_block_failed,
    touch_order_updated_at,
    upsert_item_block,
    upsert_order_block,
)
from app.services.personnel_orders_editorial.write_lock import ensure_draft_writable


def scope_allows(
    scope: Optional[Mapping[str, Any]],
    *,
    locale: str,
    block_type: str,
    item_id: Optional[int] = None,
    block_id: Optional[int] = None,
    level: str,
) -> bool:
    """Return True if this block should be (re)generated under ``scope``."""
    if not scope:
        return True
    if scope.get("item_id") is not None:
        if level == "order":
            return False
        if item_id is None or int(scope["item_id"]) != int(item_id):
            return False
    if scope.get("locale") is not None:
        if str(scope["locale"]).strip().lower() != str(locale).strip().lower():
            return False
    if scope.get("block_type") is not None:
        if str(scope["block_type"]).strip().lower() != str(block_type).strip().lower():
            return False
    if scope.get("block_id") is not None:
        if block_id is None or int(scope["block_id"]) != int(block_id):
            return False
    return True


def generate_editorial(
    order_id: int,
    *,
    user_id: Optional[int],
    scope: Optional[Dict[str, Any]] = None,
    conn: Optional[Connection] = None,
    allow_document_correction: bool = False,
) -> Dict[str, Any]:
    """Create missing blocks and regenerate generated_text; never clears overrides.

    Failure isolation: each block is generated in its own try/except. A failed
    block is persisted as GENERATION_FAILED; other successful blocks in the same
    call remain committed in the same transaction.
    """
    require_available(conn)
    scope = dict(scope) if scope else None

    # Batch reconstruction passes its outer transaction here so headers, items,
    # evidence and generated presentations commit (or roll back) together.
    with (nullcontext(conn) if conn is not None else engine.begin()) as active_conn:
        scope_tokens = lock_personnel_order_evidence_scopes_tx(active_conn, order_ids=[order_id])
        order = fetch_order(active_conn, order_id)
        assert_order_not_archived(order)
        if not allow_document_correction:
            ensure_draft_writable(order)

        items = load_items(active_conn, order_id)
        employee_ids = [
            int(i["employee_id"]) for i in items if i.get("employee_id") is not None
        ]
        bases: Dict[int, Dict[str, Any]] = {}
        unpaid_item_ids: list[int] = []
        for item in items:
            if scope and scope.get("item_id") is not None and int(scope["item_id"]) != int(item["item_id"]):
                continue
            item_type_code = str(item["item_type_code"]).strip().upper()
            if item_type_code == "LEAVE.UNPAID.GRANT":
                unpaid_item_ids.append(int(item["item_id"]))
            elif item_type_code != ORDER_TYPE_SUPPLEMENTARY_PAY:
                bases[int(item["item_id"])] = ensure_default_basis(active_conn, item)

        # A normalized unpaid-leave basis is canonical.  Do not manufacture a
        # row before checking for it: only an actually absent row may fall back
        # to the legacy payload of an older draft.
        bases.update(load_bases(active_conn, unpaid_item_ids))

        for basis in bases.values():
            if basis.get("subject_employee_id") is not None:
                employee_ids.append(int(basis["subject_employee_id"]))
        names = load_employee_names(active_conn, employee_ids)
        legacy = load_legacy_localized(active_conn, order_id)

        existing_order_blocks = {
            (b["locale"], b["block_type"]): b for b in load_order_blocks(active_conn, order_id)
        }
        is_first_generate = len(existing_order_blocks) == 0

        order_ctx = {
            "order_type_code": order.get("order_type_code"),
            "legal_basis_article": order.get("legal_basis_article"),
        }

        for locale in ALLOWED_LOCALES:
            for block_type in ORDER_BLOCK_TYPES:
                existing = existing_order_blocks.get((locale, block_type))
                current_id = int(existing["block_id"]) if existing else None
                if not scope_allows(
                    scope,
                    locale=locale,
                    block_type=block_type,
                    block_id=current_id,
                    level="order",
                ):
                    continue

                try:
                    generated = generate_order_block(block_type, locale, order_ctx)
                    legacy_field = None
                    if block_type in (ORDER_BLOCK_TYPE_TITLE, ORDER_BLOCK_TYPE_PREAMBLE):
                        legacy_field = (legacy.get(locale) or {}).get(block_type)
                    old_status, new_status = upsert_order_block(
                        active_conn,
                        order_id=int(order_id),
                        locale=locale,
                        block_type=block_type,
                        generated=generated,
                        user_id=user_id,
                        legacy_text=legacy_field,
                        is_first=is_first_generate and existing is None,
                    )
                    write_editorial_audit(
                        event_type=(
                            "EDITORIAL_GENERATED" if existing is None else "EDITORIAL_REGENERATED"
                        ),
                        actor_user_id=user_id,
                        metadata={
                            "order_id": int(order_id),
                            "block_type": block_type,
                            "locale": locale,
                            "user_id": user_id,
                            "result": "ok",
                            "generator_version": generated["generator_version"],
                            "old_review_status": old_status or None,
                            "new_review_status": new_status,
                        },
                        conn=active_conn,
                    )
                except Exception:
                    mark_order_block_failed(
                        active_conn,
                        order_id=int(order_id),
                        locale=locale,
                        block_type=block_type,
                    )
                    write_editorial_audit(
                        event_type="EDITORIAL_GENERATED",
                        actor_user_id=user_id,
                        success=False,
                        metadata={
                            "order_id": int(order_id),
                            "block_type": block_type,
                            "locale": locale,
                            "user_id": user_id,
                            "result": "GENERATION_FAILED",
                            "generator_version": None,
                            "old_review_status": None,
                            "new_review_status": REVIEW_STATUS_GENERATION_FAILED,
                        },
                        conn=active_conn,
                    )

        existing_item_blocks = {
            (int(b["order_item_id"]), b["locale"], b["block_type"]): b
            for b in load_item_blocks(active_conn, order_id=order_id)
        }

        for item in items:
            item_id = int(item["item_id"])
            basis_required, unsupported = resolve_basis_required(str(item["item_type_code"]))
            force_review = unsupported is not None
            employee_name = names.get(int(item["employee_id"])) if item.get("employee_id") else None
            item_ctx = build_item_ctx(item, employee_name)
            basis = bases.get(item_id)
            item_type_code = str(item["item_type_code"]).strip().upper()
            if basis is None and item_type_code not in {ORDER_TYPE_SUPPLEMENTARY_PAY, "LEAVE.UNPAID.GRANT"}:
                if scope and scope.get("item_id") is not None and int(scope["item_id"]) != item_id:
                    continue
                basis = ensure_default_basis(active_conn, item)
                bases[item_id] = basis
            subject_id = basis.get("subject_employee_id") if basis else None
            subject_name = names.get(int(subject_id)) if subject_id is not None else employee_name
            basis_fact = {
                "item_type_code": item["item_type_code"],
                "recall_payload": item_ctx.get("recall_payload"),
                "effective_date": item_ctx.get("effective_date"),
                "childcare_payload": item_ctx.get("childcare_payload"),
                "org_unit_name": item_ctx.get("org_unit_name"),
                "basis_type": basis.get("basis_type") if basis else None,
                "subject_employee_id": subject_id,
                "subject_employee_name": subject_name,
                "document_date": iso_date(basis.get("document_date")) if basis else None,
                "document_number": basis.get("document_number") if basis else None,
                "free_text": basis.get("free_text") if basis else None,
            }
            if basis is None and item_type_code == "LEAVE.UNPAID.GRANT":
                # Legacy drafts stored the application only in payload. Read
                # it solely when no normalized basis row exists; new and
                # normalized records always win, even when their date/number
                # is blank.
                legacy_basis = item_ctx.get("basis") if isinstance(item_ctx.get("basis"), Mapping) else {}
                if str(legacy_basis.get("kind") or "").strip().upper() == "PERSONAL_APPLICATION":
                    basis_fact.update({
                        "basis_type": "PERSONAL_APPLICATION",
                        "document_date": legacy_basis.get("date"),
                        "document_number": legacy_basis.get("number"),
                    })

            for locale in ALLOWED_LOCALES:
                for block_type in ITEM_BLOCK_TYPES:
                    existing = existing_item_blocks.get((item_id, locale, block_type))
                    current_id = int(existing["block_id"]) if existing else None
                    if not scope_allows(
                        scope,
                        locale=locale,
                        block_type=block_type,
                        item_id=item_id,
                        block_id=current_id,
                        level="item",
                    ):
                        continue

                    try:
                        if block_type == ITEM_BLOCK_TYPE_BODY:
                            generated = generate_item_body(locale, item_ctx)
                        else:
                            if str(item["item_type_code"]).strip().upper() == ORDER_TYPE_SUPPLEMENTARY_PAY:
                                generated = generate_supplementary_pay_basis(locale)
                            else:
                                generated = generate_basis_text(locale, basis_fact)
                        old_status, new_status = upsert_item_block(
                            active_conn,
                            order_item_id=item_id,
                            locale=locale,
                            block_type=block_type,
                            generated=generated,
                            basis_required=(
                                basis_required if block_type == ITEM_BLOCK_TYPE_BASIS else False
                            ),
                            force_review_required=(
                                force_review and block_type == ITEM_BLOCK_TYPE_BASIS
                            ),
                        )
                        write_editorial_audit(
                            event_type=(
                                "EDITORIAL_GENERATED"
                                if existing is None
                                else "EDITORIAL_REGENERATED"
                            ),
                            actor_user_id=user_id,
                            metadata={
                                "order_id": int(order_id),
                                "item_id": item_id,
                                "block_type": block_type,
                                "locale": locale,
                                "user_id": user_id,
                                "result": "ok",
                                "generator_version": generated["generator_version"],
                                "old_review_status": old_status or None,
                                "new_review_status": new_status,
                            },
                            conn=active_conn,
                        )
                    except Exception:
                        mark_item_block_failed(
                            active_conn,
                            order_item_id=item_id,
                            locale=locale,
                            block_type=block_type,
                            basis_required=(
                                basis_required if block_type == ITEM_BLOCK_TYPE_BASIS else False
                            ),
                        )
                        write_editorial_audit(
                            event_type="EDITORIAL_GENERATED",
                            actor_user_id=user_id,
                            success=False,
                            metadata={
                                "order_id": int(order_id),
                                "item_id": item_id,
                                "block_type": block_type,
                                "locale": locale,
                                "user_id": user_id,
                                "result": "GENERATION_FAILED",
                                "generator_version": None,
                                "old_review_status": None,
                                "new_review_status": REVIEW_STATUS_GENERATION_FAILED,
                            },
                            conn=active_conn,
                        )

        touch_order_updated_at(active_conn, int(order_id))
        advance_personnel_order_evidence_scopes_tx(active_conn, tokens=scope_tokens)

    # Lazy import avoids cycle with service (which does not import this module).
    if conn is not None:
        return {"order_id": int(order_id), "generated_in_existing_transaction": True}
    # Lazy import avoids cycle with service (which does not import this module).
    from app.services.personnel_orders_editorial.service import get_editorial_state
    return get_editorial_state(int(order_id))
