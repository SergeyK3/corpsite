"""Pure text generators for personnel order editorial blocks (WP-PO-EDIT-002).

No React, HTML, or PDF — plain bilingual templates ported from the print spike.
"""
from __future__ import annotations

from datetime import date
from typing import Any, Dict, Mapping

from app.db.models.personnel_orders import (
    BASIS_TYPE_COMMISSION_PROTOCOL,
    BASIS_TYPE_COURT_ACT,
    BASIS_TYPE_MANAGEMENT_SUBMISSION,
    BASIS_TYPE_MEDICAL_CONCLUSION,
    BASIS_TYPE_MEMO,
    BASIS_TYPE_OTHER,
    BASIS_TYPE_PERSONAL_APPLICATION,
    ITEM_BLOCK_TYPE_BASIS,
    ITEM_BLOCK_TYPE_BODY,
    ORDER_BLOCK_TYPE_CLOSING,
    ORDER_BLOCK_TYPE_PREAMBLE,
    ORDER_BLOCK_TYPE_TITLE,
    ORDER_TYPE_COMPOSITE,
    ORDER_TYPE_CONCURRENT_DUTY_END,
    ORDER_TYPE_CONCURRENT_DUTY_START,
    ORDER_TYPE_HIRE,
    ORDER_TYPE_LEAVE_CHILDCARE_GRANT,
    ORDER_TYPE_RETURN_FROM_CHILDCARE_LEAVE,
    ORDER_TYPE_SUPPLEMENTARY_PAY,
    ORDER_TYPE_TERMINATION,
    ORDER_TYPE_TRANSFER,
)
from app.services.personnel_orders_editorial.constants import (
    GENERATOR_KEY_ITEM_BASIS,
    GENERATOR_KEY_ITEM_BODY,
    GENERATOR_KEY_ORDER_CLOSING,
    GENERATOR_KEY_ORDER_PREAMBLE,
    GENERATOR_KEY_ORDER_TITLE,
    GENERATOR_VERSION,
)
from app.services.personnel_orders_editorial.fingerprint import compute_fingerprint
from app.services.personnel_orders_editorial.position_dictionary import localized_personnel_order_position
from app.services.personnel_order_termination_reason import termination_reason_text
from app.services.personnel_order_childcare_contract import TEXTS as CHILDCARE_TEXTS, childcare_values, render_childcare

DOCUMENT_TITLES: Dict[str, Dict[str, str]] = {
    ORDER_TYPE_HIRE: {
        "kk": "Жұмысқа қабылдау туралы",
        "ru": "О приёме на работу",
    },
    ORDER_TYPE_RETURN_FROM_CHILDCARE_LEAVE: {
        "kk": "Бала күтіміне байланысты демалыстан жұмысқа шығу туралы",
        "ru": "О выходе на работу из отпуска по уходу за ребёнком",
    },
    ORDER_TYPE_TRANSFER: {
        "kk": "Ауыстыру туралы",
        "ru": "О переводе",
    },
    ORDER_TYPE_TERMINATION: {
        "kk": "Жұмыстан босату туралы",
        "ru": "Об увольнении",
    },
    ORDER_TYPE_CONCURRENT_DUTY_START: {
        "kk": "Қоса атқаруды белгілеу туралы",
        "ru": "Об установлении совмещения",
    },
    ORDER_TYPE_CONCURRENT_DUTY_END: {
        "kk": "Қоса атқаруды тоқтату туралы",
        "ru": "О прекращении совмещения",
    },
    ORDER_TYPE_SUPPLEMENTARY_PAY: {
        "kk": "Қосымша ақы туралы",
        "ru": "О дополнительной оплате",
    },
    ORDER_TYPE_COMPOSITE: {
        "kk": "Кадрлық өзгерістер туралы",
        "ru": "О кадровых изменениях",
    },
    "LEAVE.ANNUAL.GRANT": {
        "kk": "Жыл сайынғы ақылы еңбек демалысын беру туралы",
        "ru": "О предоставлении ежегодного оплачиваемого трудового отпуска",
    },
    "LEAVE.UNPAID.GRANT": {
        "kk": "Жалақы сақталмайтын демалыс беру туралы",
        "ru": "О предоставлении отпуска без сохранения заработной платы",
    },
    ORDER_TYPE_LEAVE_CHILDCARE_GRANT: {
        "kk": CHILDCARE_TEXTS["title_kk"],
        "ru": CHILDCARE_TEXTS["title_ru"],
    },
}

_RU_MONTHS = (
    "января",
    "февраля",
    "марта",
    "апреля",
    "мая",
    "июня",
    "июля",
    "августа",
    "сентября",
    "октября",
    "ноября",
    "декабря",
)
_KK_MONTHS = (
    "қаңтар",
    "ақпан",
    "наурыз",
    "сәуір",
    "мамыр",
    "маусым",
    "шілде",
    "тамыз",
    "қыркүйек",
    "қазан",
    "қараша",
    "желтоқсан",
)


def _dash(value: Any) -> str:
    text = str(value or "").strip()
    return text or "—"


def _clean(value: Any) -> str:
    return str(value or "").strip()


def _locale(locale: str) -> str:
    normalized = str(locale or "").strip().lower()
    if normalized not in {"kk", "ru"}:
        raise ValueError(f"Unsupported locale: {locale}")
    return normalized


def format_personnel_order_date_numeric(value: Any) -> str:
    """Common numeric date formatter for bilingual personnel-order templates."""
    raw = _clean(value)
    if not raw:
        return ""
    try:
        return date.fromisoformat(raw[:10]).strftime("%d.%m.%Y")
    except ValueError:
        return raw


def _format_date(value: Any, locale: str) -> str:
    raw = _clean(value)
    if not raw:
        return "—"
    # Accept YYYY-MM-DD or date/datetime iso strings.
    match = None
    if len(raw) >= 10 and raw[4] == "-" and raw[7] == "-":
        try:
            year = int(raw[0:4])
            month = int(raw[5:7])
            day = int(raw[8:10])
            if 1 <= month <= 12 and 1 <= day <= 31:
                match = (year, month, day)
        except ValueError:
            match = None
    if match is None:
        return raw
    year, month, day = match
    if locale == "kk":
        return f"{year} жылғы {day} {_KK_MONTHS[month - 1]}"
    return f"{day} {_RU_MONTHS[month - 1]} {year} года"


def _format_date_from(value: Any, locale: str) -> str:
    """Format a start date; Kazakh requires the ablative month form."""
    raw = _clean(value)
    if locale != "kk" or len(raw) < 10 or raw[4] != "-" or raw[7] != "-":
        return _format_date(value, locale)
    try:
        year, month, day = int(raw[:4]), int(raw[5:7]), int(raw[8:10])
    except ValueError:
        return _format_date(value, locale)
    if not (1 <= month <= 12 and 1 <= day <= 31):
        return _format_date(value, locale)
    kk_months_from = (
        "қаңтардан", "ақпаннан", "наурыздан", "сәуірден",
        "мамырдан", "маусымнан", "шілдеден", "тамыздан",
        "қыркүйектен", "қазаннан", "қарашадан", "желтоқсаннан",
    )
    return f"{year} жылғы {day} {kk_months_from[month - 1]}"


def _format_rate_value(rate: Any) -> str:
    if rate is None or rate == "":
        return "—"
    try:
        if isinstance(rate, bool):
            raise ValueError
        numeric = float(str(rate).replace(",", "."))
    except (TypeError, ValueError):
        raw = _clean(rate)
        return raw or "—"
    if numeric == int(numeric):
        return f"{int(numeric)},0"
    text = f"{numeric:.2f}".rstrip("0").rstrip(".")
    return text.replace(".", ",")


def _format_rate(rate: Any, locale: str) -> str:
    formatted = _format_rate_value(rate)
    if formatted == "—":
        return formatted
    unit = "мөлшерлеме" if locale == "kk" else "ставки"
    return f"{formatted} {unit}"


def _localized_name(value: Any, locale: str) -> str:
    if isinstance(value, Mapping):
        preferred = _clean(value.get(locale))
        if preferred:
            return preferred
        for key in ("kk", "ru", "name"):
            fallback = _clean(value.get(key))
            if fallback:
                return fallback
        return "—"
    return _dash(value)


def _localized_position(value: Any, locale: str) -> str:
    return localized_personnel_order_position(value, locale)


def _leave_work_periods(item_ctx: Mapping[str, Any]) -> list[Dict[str, Any]]:
    """Return the current array form, with a read-only legacy fallback."""
    raw_periods = item_ctx.get("work_periods")
    if isinstance(raw_periods, list):
        periods = [dict(period) for period in raw_periods if isinstance(period, Mapping)]
        if periods:
            return periods
    if any(
        item_ctx.get(key) not in (None, "")
        for key in ("work_period_start", "work_period_end", "work_period_days")
    ):
        return [{
            "start": item_ctx.get("work_period_start"),
            "end": item_ctx.get("work_period_end"),
            "days": item_ctx.get("work_period_days"),
        }]
    return []


def _leave_basis(item_ctx: Mapping[str, Any], locale: str) -> str:
    basis = item_ctx.get("basis")
    basis = basis if isinstance(basis, Mapping) else {}
    raw_date = _clean(basis.get("date"))
    date = _format_date(raw_date, locale) if raw_date else ""
    number = _clean(basis.get("number"))
    if locale == "kk":
        if date:
            number_part = f" № {number}" if number else ""
            return f"Негіз: {date} күнгі жеке өтініш{number_part}."
        if number:
            return f"Негіз: № {number} жеке өтініш."
        return "Негіз: жеке өтініш."
    if date:
        number_part = f" № {number}" if number else ""
        return f"Основание: личное заявление от {date}{number_part}."
    if number:
        return f"Основание: личное заявление № {number}."
    return "Основание: личное заявление."


def _result(
    *,
    generated_text: str,
    generator_key: str,
    fingerprint_payload: Dict[str, Any],
) -> Dict[str, str]:
    payload = dict(fingerprint_payload)
    payload["generator_key"] = generator_key
    payload["generator_version"] = GENERATOR_VERSION
    return {
        "generated_text": generated_text,
        "generator_key": generator_key,
        "generator_version": GENERATOR_VERSION,
        "source_fingerprint": compute_fingerprint(payload),
    }


def generate_order_block(
    block_type: str,
    locale: str,
    order_ctx: Mapping[str, Any],
) -> Dict[str, str]:
    """Generate an order-level block (title / preamble / closing)."""
    lang = _locale(locale)
    normalized_type = str(block_type or "").strip().lower()
    order_type = str(order_ctx.get("order_type_code") or "").strip().upper()
    legal_basis = _clean(order_ctx.get("legal_basis_article"))

    if order_type == "LEAVE.ANNUAL.RECALL":
        from app.services.personnel_order_recall_contract import TEXTS
        value = TEXTS[f"{normalized_type}_{lang}"] if normalized_type in {"title", "preamble"} else ""
        return _result(generated_text=value, generator_key=f"annual_recall.{normalized_type}", fingerprint_payload={"type": order_type, "locale": lang, "text": value})
    if normalized_type == ORDER_BLOCK_TYPE_TITLE:
        titles = DOCUMENT_TITLES.get(order_type) or DOCUMENT_TITLES[ORDER_TYPE_COMPOSITE]
        text = titles.get(lang) or titles["ru"]
        return _result(
            generated_text=text,
            generator_key=GENERATOR_KEY_ORDER_TITLE,
            fingerprint_payload={
                "block_type": ORDER_BLOCK_TYPE_TITLE,
                "locale": lang,
                "order_type_code": order_type or None,
            },
        )

    if normalized_type == ORDER_BLOCK_TYPE_PREAMBLE:
        if order_type == ORDER_TYPE_LEAVE_CHILDCARE_GRANT:
            preamble = CHILDCARE_TEXTS[f"preamble_{lang}"]
        elif order_type == ORDER_TYPE_RETURN_FROM_CHILDCARE_LEAVE:
            # The legal ground for this temporary wording will be confirmed
            # separately; do not infer an article or a paragraph.
            preamble = (
                "Қазақстан Республикасының Еңбек кодексіне сәйкес"
                if lang == "kk"
                else "В соответствии с Трудовым кодексом Республики Казахстан"
            )
        elif order_type == ORDER_TYPE_SUPPLEMENTARY_PAY:
            preamble = (
                "Қосымша ақының шарттары DOCX-пен салыстырылғаннан кейін нақтыланады."
                if lang == "kk"
                else "Условия дополнительной оплаты уточняются после сверки с DOCX."
            )
        elif lang == "kk":
            preamble = (
                f"Қазақстан Республикасының Еңбек кодексінің {legal_basis} бабына сәйкес"
                if legal_basis
                else "Қазақстан Республикасының Еңбек кодексіне сәйкес"
            )
        else:
            preamble = (
                f"В соответствии со статьёй {legal_basis} Трудового кодекса Республики Казахстан"
                if legal_basis
                else "В соответствии с Трудовым кодексом Республики Казахстан"
            )
        # The directive is presentation chrome, rendered once by the shared
        # document/print templates.  Keeping it out of the editorial preamble
        # prevents duplicate order verbs in old and regenerated documents.
        text = preamble
        return _result(
            generated_text=text,
            generator_key=GENERATOR_KEY_ORDER_PREAMBLE,
            fingerprint_payload={
                "block_type": ORDER_BLOCK_TYPE_PREAMBLE,
                "locale": lang,
                "order_type_code": order_type or None,
                "legal_basis_article": legal_basis or None,
            },
        )

    if normalized_type == ORDER_BLOCK_TYPE_CLOSING:
        if order_type in {ORDER_TYPE_RETURN_FROM_CHILDCARE_LEAVE, "LEAVE.UNPAID.GRANT", ORDER_TYPE_LEAVE_CHILDCARE_GRANT}:
            return _result(
                generated_text="",
                generator_key=GENERATOR_KEY_ORDER_CLOSING,
                fingerprint_payload={
                    "block_type": ORDER_BLOCK_TYPE_CLOSING,
                    "locale": lang,
                    "order_type_code": order_type,
                },
            )
        if lang == "kk":
            text = "Бұйрықты орындалу бақылауын өзімде қалдырамын."
        else:
            text = "Контроль за исполнением приказа оставляю за собой."
        return _result(
            generated_text=text,
            generator_key=GENERATOR_KEY_ORDER_CLOSING,
            fingerprint_payload={
                "block_type": ORDER_BLOCK_TYPE_CLOSING,
                "locale": lang,
            },
        )

    raise ValueError(f"Unsupported order block_type: {block_type}")


def generate_item_body(locale: str, item_ctx: Mapping[str, Any]) -> Dict[str, str]:
    """Generate item body text (ported from personnelOrderPrintItemText.ts)."""
    lang = _locale(locale)
    item_type = str(item_ctx.get("item_type_code") or "").strip().upper()
    if item_type == "LEAVE.ANNUAL.RECALL":
        from app.services.personnel_order_recall_contract import values, render
        data = values(item_ctx.get("recall_payload") or {}, item_ctx.get("effective_date"))
        return _result(generated_text=render(f"body_template_{lang}", data), generator_key=GENERATOR_KEY_ITEM_BODY, fingerprint_payload={"type": item_type, "locale": lang, "values": data})
    if item_type == ORDER_TYPE_LEAVE_CHILDCARE_GRANT:
        values = childcare_values(item_ctx.get("childcare_payload") or {}, org_unit_ru=_localized_name(item_ctx.get("org_unit_name"), "ru"))
        return _result(generated_text=render_childcare(f"body_template_{lang}", values), generator_key=GENERATOR_KEY_ITEM_BODY, fingerprint_payload={"type": item_type, "locale": lang, "values": values})
    employee_name = item_ctx.get("employee_name")
    effective_date = item_ctx.get("effective_date")
    org_unit_name = item_ctx.get("org_unit_name")
    position_name = item_ctx.get("position_name")
    to_org_unit_name = item_ctx.get("to_org_unit_name")
    to_position_name = item_ctx.get("to_position_name")
    rate = item_ctx.get("rate")
    to_rate = item_ctx.get("to_rate")
    concurrent_rate = item_ctx.get("concurrent_rate")
    remaining_rate = item_ctx.get("remaining_rate")
    total_rate = item_ctx.get("total_rate")
    termination_reason = item_ctx.get("termination_reason")
    leave_start = item_ctx.get("leave_start")
    leave_end = item_ctx.get("leave_end")
    leave_days = item_ctx.get("leave_days")
    leave_period_type = item_ctx.get("leave_period_type")
    work_periods = _leave_work_periods(item_ctx)
    vacation_benefit_applicable = bool(item_ctx.get("vacation_benefit_applicable"))
    vacation_benefit_rule = _clean(item_ctx.get("vacation_benefit_rule"))

    fio = _dash(employee_name)
    date = _format_date(effective_date, lang)

    if item_type == "LEAVE.ANNUAL.GRANT":
        org = _localized_name(org_unit_name, lang)
        position = _localized_position(position_name, lang)
        leave_start_text = _format_date(leave_start, lang)
        leave_end_text = _format_date(leave_end, lang)
        days = _dash(leave_days)
        if lang == "kk":
            periods_text = "; ".join(
                f"{_format_date(period.get('start'), lang)} – {_format_date(period.get('end'), lang)}: {_dash(period.get('days'))} күн"
                for period in work_periods
            ) or "—"
            benefit_text = (
                f" Демалыс жәрдемақысы: {vacation_benefit_rule or 'қарастырылған'}."
                if vacation_benefit_applicable
                else ""
            )
            text = (
                f"{fio}, «{org}» бөлімшесінің «{position}» қызметкеріне "
                f"{leave_start_text} мен {leave_end_text} аралығында {days} күнтізбелік күнге "
                f"жыл сайынғы ақылы еңбек демалысы берілсін. Жұмыс кезеңдері: {periods_text}."
                f"{benefit_text} {_leave_basis(item_ctx, lang)}"
            )
        else:
            periods_text = "; ".join(
                f"{_format_date(period.get('start'), lang)} – {_format_date(period.get('end'), lang)}: {_dash(period.get('days'))} календарных дней"
                for period in work_periods
            ) or "—"
            benefit_text = (
                f" Пособие к отпуску: {vacation_benefit_rule or 'предусмотрено'}."
                if vacation_benefit_applicable
                else ""
            )
            text = (
                f"Предоставить {fio}, {position} подразделения «{org}», ежегодный оплачиваемый "
                f"трудовой отпуск с {leave_start_text} по {leave_end_text} включительно "
                f"продолжительностью {days} календарных дней. Рабочие периоды: {periods_text}."
                f"{benefit_text} {_leave_basis(item_ctx, lang)}"
            )
    elif item_type == "LEAVE.UNPAID.GRANT":
        org = _localized_name(org_unit_name, lang)
        position = (
            _clean(item_ctx.get("position_document_possessive_kk"))
            if lang == "kk"
            else None
        ) or _localized_position(position_name, lang)
        days = _dash(leave_days)
        if leave_period_type == "SINGLE_DAY":
            period_phrase = _format_date(leave_start, lang)
        else:
            leave_start_text = _format_date(leave_start, lang)
            leave_end_text = _format_date(leave_end, lang)
            period_phrase = (
                f"{leave_start_text} мен {leave_end_text} аралығында"
                if lang == "kk"
                else f"с {leave_start_text} по {leave_end_text} включительно"
            )
        if lang == "kk":
            text = (
                f"{fio}, «{org}» бөлімшесінің «{position}» қызметкеріне "
                f"{period_phrase} {days} күнтізбелік күнге "
                "жалақы сақталмайтын демалыс берілсін."
            )
        else:
            text = (
                f"Предоставить {fio}, {position} подразделения «{org}», отпуск без сохранения "
                f"заработной платы {period_phrase} "
                f"продолжительностью {days} календарных дней."
            )
    elif item_type == ORDER_TYPE_HIRE:
        org = _localized_name(org_unit_name, lang)
        position = _localized_position(position_name, lang)
        rate_value = _format_rate_value(rate)
        if lang == "kk":
            text = (
                f"{fio} «{org}» бөлімшесіне «{position}» лауазымына "
                f"{rate_value} мөлшерлемесінде {date} бастап жұмысқа қабылдансын."
            )
        else:
            text = (
                f"Принять на работу {fio} в подразделение «{org}» на должность "
                f"«{position}» со ставкой {rate_value} с {date}."
            )
    elif item_type == ORDER_TYPE_RETURN_FROM_CHILDCARE_LEAVE:
        has_effective_date = effective_date not in (None, "")
        org = _localized_name(org_unit_name, lang)
        position = _localized_position(position_name, lang)
        has_assignment_context = org != "—" and position != "—"
        rate_value = _format_rate_value(rate)
        if lang == "kk":
            kk_org = "Инсульт орталығы" if str(org).casefold() == "инсультный центр" else org
            assignment_part = f"{kk_org}ның {position}" if has_assignment_context else ""
            rate_part = f" {rate_value} мөлшерлемемен" if rate_value else ""
            date_part = f" {_format_date_from(effective_date, lang)} бастап" if has_effective_date else ""
            text = f"{date_part.strip()} {assignment_part} {fio}ға{rate_part} бала күтіміне байланысты демалыстан жұмысқа шығуға рұқсат берілсін."
        else:
            ru_position = "врача (ординатора)" if str(position).casefold() == "врач (ординатор)" else position.lower()
            ru_org = "Инсультного центра" if str(org).casefold() == "инсультный центр" else org
            assignment_part = f" в должности {ru_position} {ru_org}" if has_assignment_context else ""
            rate_part = f" на {rate_value} ставки" if rate_value else ""
            date_part = f" с {date}" if has_effective_date else ""
            text = f"Разрешить сотруднику {fio} приступить к работе в связи с выходом из отпуска по уходу за ребёнком{assignment_part}{rate_part}{date_part}."
    elif item_type == ORDER_TYPE_TRANSFER:
        org = _localized_name(to_org_unit_name or org_unit_name, lang)
        position = _localized_position(to_position_name or position_name, lang)
        rate_value = (
            _format_rate_value(to_rate)
            if to_rate is not None and to_rate != ""
            else None
        )
        if lang == "kk":
            rate_part = f", {rate_value} мөлшерлемесінде" if rate_value else ""
            text = (
                f"{fio} «{org}» бөлімшесіне «{position}» лауазымына"
                f"{rate_part} {date} бастап ауыстырылсын."
            )
        else:
            rate_part = f" со ставкой {rate_value}" if rate_value else ""
            text = (
                f"Перевести {fio} в подразделение «{org}» на должность "
                f"«{position}»{rate_part} с {date}."
            )
    elif item_type == ORDER_TYPE_TERMINATION:
        reason = _clean(termination_reason_text(termination_reason, lang)) or None
        org = _localized_name(org_unit_name, lang)
        position = _localized_position(position_name, lang)
        unused_leave_days = _clean(item_ctx.get("termination_unused_leave_days"))
        if lang == "kk":
            reason_part = f" Себебі: {reason}." if reason else ""
            settlement = f" Бухгалтерлік есеп бөлімі пайдаланылмаған еңбек демалысының {unused_leave_days} күнтізбелік күніне есеп айырысу жүргізсін." if unused_leave_days else ""
            text = f"{org} бөлімшесінің {position} қызметкері {fio} еңбек шарты {date} бастап бұзылсын.{reason_part}{settlement}"
        else:
            reason_part = f" Причина увольнения: {reason}." if reason else ""
            settlement = f" Бухгалтерии произвести расчёт за {unused_leave_days} календарных дней неиспользованного трудового отпуска." if unused_leave_days else ""
            text = f"Уволить {fio}, {position} подразделения «{org}», {date}.{reason_part}{settlement}"
    elif item_type == ORDER_TYPE_CONCURRENT_DUTY_START:
        concurrent_value = _format_rate_value(concurrent_rate)
        total = (
            _format_rate(total_rate, lang)
            if total_rate is not None and total_rate != ""
            else None
        )
        if lang == "kk":
            total_part = f" Жалпы мөлшерлеме: {total}." if total else ""
            text = (
                f"{fio} үшін қоса атқару {concurrent_value} мөлшерлемесінде "
                f"{date} бастап белгіленсін.{total_part}"
            )
        else:
            total_part = f" Итоговая ставка: {total}." if total else ""
            text = (
                f"Установить {fio} совмещение в размере {concurrent_value} ставки "
                f"с {date}.{total_part}"
            )
    elif item_type == ORDER_TYPE_CONCURRENT_DUTY_END:
        remaining = (
            _format_rate(remaining_rate, lang)
            if remaining_rate is not None and remaining_rate != ""
            else None
        )
        concurrent = (
            _format_rate(concurrent_rate, lang)
            if concurrent_rate is not None and concurrent_rate != ""
            else None
        )
        if lang == "kk":
            rem = f" Қалған мөлшерлеме: {remaining}." if remaining else ""
            rem_concurrent = f" Алынатын мөлшерлеме: {concurrent}." if concurrent else ""
            text = (
                f"{fio} үшін қоса атқару {date} бастап тоқтатылсын."
                f"{rem}{rem_concurrent}"
            )
        else:
            rem = f" Остающаяся ставка: {remaining}." if remaining else ""
            rem_concurrent = f" Снимаемая ставка: {concurrent}." if concurrent else ""
            text = f"Прекратить совмещение для {fio} с {date}.{rem}{rem_concurrent}"
    elif item_type == ORDER_TYPE_SUPPLEMENTARY_PAY:
        # The journal gives neither the amount nor the period, basis,
        # position or unit.  Keep this deliberately non-assertive until the
        # individual DOCX is reviewed.
        if lang == "kk":
            text = (
                f"{fio} үшін қосымша ақы: мөлшері, кезеңі, негізі және шарттары "
                "DOCX-пен салыстыруды талап етеді."
            )
        else:
            text = (
                f"Дополнительная оплата для {fio}: размер, период, основание и условия "
                "требуют сверки с DOCX."
            )
    else:
        if lang == "kk":
            text = f"{fio}, күні {date}."
        else:
            text = f"{fio}, дата {date}."

    return _result(
        generated_text=text,
        generator_key=GENERATOR_KEY_ITEM_BODY,
        fingerprint_payload={
            "block_type": ITEM_BLOCK_TYPE_BODY,
            "locale": lang,
            "item_type_code": item_type or None,
            "employee_name": _clean(employee_name) or None,
            "effective_date": _clean(effective_date) or None,
            "org_unit_name": org_unit_name if org_unit_name not in (None, "") else None,
            "position_name": position_name if position_name not in (None, "") else None,
            "to_org_unit_name": to_org_unit_name if to_org_unit_name not in (None, "") else None,
            "to_position_name": to_position_name if to_position_name not in (None, "") else None,
            "rate": rate if rate not in (None, "") else None,
            "specialty": _clean(item_ctx.get("specialty")) or None,
            "to_rate": to_rate if to_rate not in (None, "") else None,
            "concurrent_rate": concurrent_rate if concurrent_rate not in (None, "") else None,
            "remaining_rate": remaining_rate if remaining_rate not in (None, "") else None,
            "total_rate": total_rate if total_rate not in (None, "") else None,
            "termination_reason": _clean(termination_reason) or None,
            "leave_start": _clean(leave_start) or None,
            "leave_end": _clean(leave_end) or None,
            "leave_days": leave_days if leave_days not in (None, "") else None,
            "leave_period_type": _clean(leave_period_type) or None,
            "work_periods": work_periods or None,
            "basis": item_ctx.get("basis") if isinstance(item_ctx.get("basis"), Mapping) else None,
            "vacation_benefit_applicable": vacation_benefit_applicable,
            "vacation_benefit_rule": vacation_benefit_rule or None,
        },
    )


def generate_basis_text(locale: str, basis_fact: Mapping[str, Any]) -> Dict[str, str]:
    """Generate basis wording (ported from personnelOrderBasisGenerate.ts)."""
    lang = _locale(locale)
    if basis_fact.get("item_type_code") == "LEAVE.ANNUAL.RECALL":
        from app.services.personnel_order_recall_contract import values, render
        data = values(basis_fact.get("recall_payload") or {}, basis_fact.get("effective_date"))
        return _result(generated_text=render(f"basis_template_{lang}", data), generator_key=GENERATOR_KEY_ITEM_BASIS, fingerprint_payload={"type": "LEAVE.ANNUAL.RECALL", "locale": lang, "values": data})
    if basis_fact.get("item_type_code") == ORDER_TYPE_LEAVE_CHILDCARE_GRANT:
        values = childcare_values(basis_fact.get("childcare_payload") or {}, org_unit_ru=_localized_name(basis_fact.get("org_unit_name"), "ru"))
        return _result(generated_text=render_childcare(f"basis_template_{lang}", values), generator_key=GENERATOR_KEY_ITEM_BASIS, fingerprint_payload={"type": ORDER_TYPE_LEAVE_CHILDCARE_GRANT, "locale": lang, "values": values})
    basis_type = str(basis_fact.get("basis_type") or "").strip().upper()
    name = _clean(basis_fact.get("subject_employee_name"))
    genitive_ru = _clean(basis_fact.get("subject_employee_name_genitive_ru")) or name
    possessive_kk = _clean(basis_fact.get("subject_employee_name_possessive_kk")) or (
        f"{name}тың" if name else ""
    )
    document_number = _clean(basis_fact.get("document_number"))
    document_date = _clean(basis_fact.get("document_date"))
    free_text = _clean(basis_fact.get("free_text"))
    item_type = str(basis_fact.get("item_type_code") or "").strip().upper()

    if basis_type == BASIS_TYPE_PERSONAL_APPLICATION:
        if item_type == ORDER_TYPE_RETURN_FROM_CHILDCARE_LEAVE:
            # The shared display layer supplies the single localized heading.
            # Keep this effective block label-free and never include the
            # employee's name for this document type.
            text = "Жеке өтініші." if lang == "kk" else "Личное заявление."
        elif item_type == "LEAVE.UNPAID.GRANT":
            formatted_date = _format_date(document_date, lang) if document_date else ""
            number_part = f" № {document_number}" if document_number else ""
            if lang == "kk":
                text = (
                    f"Негіз: {formatted_date} күнгі жеке өтініш{number_part}."
                    if formatted_date
                    else f"Негіз: Жеке өтініш{number_part}."
                )
            else:
                text = (
                    f"Основание: личное заявление от {formatted_date}{number_part}."
                    if formatted_date
                    else f"Основание: Личное заявление{number_part}."
                )
        elif lang == "ru":
            text = (
                "Основание: личное заявление."
                if not genitive_ru
                else f"Основание: личное заявление {genitive_ru}."
            )
        else:
            text = (
                "Негіз: жеке өтініш."
                if not possessive_kk
                else f"Негіз: {possessive_kk} жеке өтініші."
            )
    elif basis_type == BASIS_TYPE_MEMO:
        if lang == "ru":
            text = (
                f"Основание: служебная записка ({name})."
                if name
                else "Основание: служебная записка."
            )
        else:
            text = (
                f"Негіз: қызметтік жазба ({name})."
                if name
                else "Негіз: қызметтік жазба."
            )
    elif basis_type == BASIS_TYPE_MANAGEMENT_SUBMISSION:
        if lang == "ru":
            text = (
                f"Основание: представление ({name})."
                if name
                else "Основание: представление."
            )
        else:
            text = f"Негіз: ұсыным ({name})." if name else "Негіз: ұсыным."
    elif basis_type == BASIS_TYPE_MEDICAL_CONCLUSION:
        text = (
            "Основание: медицинское заключение."
            if lang == "ru"
            else "Негіз: медициналық қорытынды."
        )
    elif basis_type == BASIS_TYPE_COMMISSION_PROTOCOL:
        parts = []
        if document_number:
            parts.append(f"№{document_number}")
        if document_date:
            parts.append(document_date)
        tail = " от ".join(parts) if parts else ""
        if lang == "ru":
            text = (
                f"Основание: протокол комиссии {tail}."
                if tail
                else "Основание: протокол комиссии."
            )
        else:
            text = (
                f"Негіз: комиссия хаттамасы {tail}."
                if tail
                else "Негіз: комиссия хаттамасы."
            )
    elif basis_type == BASIS_TYPE_COURT_ACT:
        text = "Основание: судебный акт." if lang == "ru" else "Негіз: сот актісі."
    else:
        # OTHER / default
        if free_text:
            text = free_text
        else:
            text = "Основание: —" if lang == "ru" else "Негіз: —"
        basis_type = basis_type or BASIS_TYPE_OTHER

    return _result(
        generated_text=text,
        generator_key=GENERATOR_KEY_ITEM_BASIS,
        fingerprint_payload={
            "block_type": ITEM_BLOCK_TYPE_BASIS,
            "locale": lang,
            "basis_type": basis_type or None,
            "subject_employee_id": basis_fact.get("subject_employee_id"),
            "subject_employee_name": name or None,
            "document_date": document_date or None,
            "document_number": document_number or None,
            "free_text": free_text or None,
        },
    )


def generate_supplementary_pay_basis(locale: str) -> Dict[str, str]:
    """State the DOCX review requirement without inventing a basis."""
    lang = _locale(locale)
    text = (
        "Негізі мен шарттары DOCX-пен салыстыруды талап етеді."
        if lang == "kk"
        else "Основание и условия требуют сверки с DOCX."
    )
    return _result(
        generated_text=text,
        generator_key=GENERATOR_KEY_ITEM_BASIS,
        fingerprint_payload={
            "block_type": ITEM_BLOCK_TYPE_BASIS,
            "locale": lang,
            "item_type_code": ORDER_TYPE_SUPPLEMENTARY_PAY,
        },
    )
