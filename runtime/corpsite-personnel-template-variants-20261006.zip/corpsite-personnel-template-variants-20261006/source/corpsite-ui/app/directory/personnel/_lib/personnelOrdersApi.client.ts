import { buildHeaders } from "@/lib/api";
import { formatThrownError } from "@/lib/i18n";
import { resolveApiUrl } from "@/lib/apiBase";
import { readTaskOrgFiltersFromSearchParams } from "@/lib/taskOrgFilters";

import type { PersonnelOrderStatus, PersonnelOrderType } from "./personnelOrderLabels";

export type { PersonnelOrderStatus, PersonnelOrderType } from "./personnelOrderLabels";
export {
  PERSONNEL_ORDER_STATUS_FILTER_OPTIONS,
  PERSONNEL_ORDER_TYPE_FILTER_OPTIONS,
  PERSONNEL_ORDER_CREATE_TYPE_OPTIONS,
  PERSONNEL_ORDER_CREATE_TYPES,
  canApplyPersonnelOrder,
  canApplyPersonnelOrderAction,
  canArchivePersonnelOrder,
  canRegisterPersonnelOrder,
  canRestorePersonnelOrder,
  canVoidPersonnelOrder,
  formatPersonnelOrderDate,
  formatPersonnelOrderDateTime,
  formatPersonnelOrderNumber,
  isEditablePersonnelOrderStatus,
  isWritablePersonnelOrder,
  isPersonnelOrderApplied,
  PERSONNEL_ORDER_APPLIED_LABEL,
  personnelOrderAppliedBadgeClass,
  personnelOrderArchivedBadgeClass,
  PERSONNEL_ORDER_ARCHIVED_LABEL,
  personnelOrderSourceModeLabel,
  personnelOrderStatusBadgeClass,
  personnelOrderStatusLabel,
  personnelOrderTypeBadgeClass,
  personnelOrderTypeLabel,
} from "./personnelOrderLabels";

export type PersonnelOrderListItem = {
  order_id: number;
  order_number?: string | null;
  order_date?: string | null;
  order_type_code: string;
  order_class: string;
  status: string;
  document_revision?: number;
  source_title?: string | null;
  source_title_locale?: "kk" | "ru" | "unknown" | null;
  source_mode: string;
  legal_basis_article?: string | null;
  signed_by_employee_id?: number | null;
  signed_by_name?: string | null;
  signed_by_position?: string | null;
  executor_name?: string | null;
  basis_summary?: string | null;
  storage_json?: Record<string, unknown> | null;
  comment?: string | null;
  void_reason?: string | null;
  voided_at?: string | null;
  voided_by?: number | null;
  created_by: number;
  created_at?: string | null;
  updated_at?: string | null;
  is_archived?: boolean;
  archive_summary_at?: string | null;
  archive_summary_by_name?: string | null;
  archive_summary_reason?: string | null;
  item_count: number;
  employee_ids: number[];
  employee_names: string[];
};

export type PersonnelOrderItem = {
  item_id: number;
  order_id: number;
  item_number: number;
  item_type_code: string;
  item_status: string;
  employee_id?: number | null;
  employee_name?: string | null;
  org_unit_id?: number | null;
  org_unit_name?: string | null;
  effective_date?: string | null;
  period_start?: string | null;
  period_end?: string | null;
  payload: Record<string, unknown>;
  void_reason?: string | null;
  voided_at?: string | null;
  voided_by?: number | null;
  created_at?: string | null;
};

export type PersonnelOrderLocalizedText = {
  localized_text_id: number;
  order_id: number;
  locale: string;
  title?: string | null;
  preamble?: string | null;
  body_text?: string | null;
  render_version: number;
  is_authoritative: boolean;
  created_at?: string | null;
  updated_at?: string | null;
};

export type PersonnelOrderAttachment = {
  attachment_id: number;
  order_id: number;
  attachment_kind: string;
  storage_type: string;
  file_path?: string | null;
  file_url?: string | null;
  file_comment?: string | null;
  locale?: string | null;
  created_by: number;
  created_at?: string | null;
};

export type PersonnelOrderPrint = {
  print_id: number;
  order_id: number;
  locale: string;
  format: string;
  file_path?: string | null;
  file_url?: string | null;
  is_signed_copy: boolean;
  render_version: number;
  generated_at?: string | null;
  generated_by?: number | null;
};

export type PersonnelOrderLinkedEvent = {
  event_id: number;
  order_id?: number | null;
  order_item_id?: number | null;
  employee_id: number;
  employee_name?: string | null;
  event_type: string;
  event_class: string;
  event_label: string;
  lifecycle_status: string;
  metadata?: Record<string, unknown> | null;
  effective_date?: string | null;
  from_org_unit_id?: number | null;
  from_org_unit_name?: string | null;
  to_org_unit_id?: number | null;
  to_org_unit_name?: string | null;
  from_position_id?: number | null;
  from_position_name?: string | null;
  to_position_id?: number | null;
  to_position_name?: string | null;
  from_rate?: number | null;
  to_rate?: number | null;
  order_ref?: string | null;
  comment?: string | null;
  created_at?: string | null;
};

export type PersonnelOrderHeader = Omit<
  PersonnelOrderListItem,
  "item_count" | "employee_ids" | "employee_names"
>;

export type PersonnelOrdersListResponse = {
  items: PersonnelOrderListItem[];
  total: number;
  limit: number;
  offset: number;
};

export type PersonnelOrderDetailResponse = {
  order: PersonnelOrderHeader;
  items: PersonnelOrderItem[];
  localized_texts: PersonnelOrderLocalizedText[];
  attachments: PersonnelOrderAttachment[];
  prints: PersonnelOrderPrint[];
  events: PersonnelOrderLinkedEvent[];
  acknowledgements?: PersonnelOrderAcknowledgement[];
};

export type PersonnelOrderDeletedTombstone = {
  order_id: number; order_number?: string | null; order_type_code: string;
  previous_status: string; deleted_at: string; deletion_reason?: string | null;
  deleted_by_user_id?: number | null; deleted_by_name?: string | null;
  deletion_mode: string; template_application_count: number;
  employees: string[];
  items: Array<{ item_id: number; item_number: number; item_type_code: string; item_status: string; employee_id?: number | null; employee_name?: string | null }>;
};

export type PersonnelOrderDocumentReview = {
  state: "NEEDS_REVIEW" | "CONFIRMED";
  document_revision: number;
  confirmed_at?: string | null;
  confirmed_by?: number | null;
  latest_reason_code?: string | null;
  latest_note?: string | null;
  blockers: Array<{ code: string; [key: string]: unknown }>;
  warnings: Array<{ code: string; [key: string]: unknown }>;
  allowed_actions: string[];
};
export type PersonnelOrderHeaderDuplicatePreview = { blocking: boolean; warnings: string[]; candidates: Array<{ order_id: number; order_number?: string | null; order_date?: string | null; order_type_code: string; status: string }> };

export type PersonnelOrderAcknowledgement = {
  acknowledgement_event_id: number;
  order_id: number;
  employee_id: number;
  event_type: "RECORDED" | "CORRECTED" | "CLEARED" | string;
  acknowledged_on?: string | null;
  created_at?: string | null;
  created_by_user_id: number;
};

/** WP-PO-EDIT-002 editorial persistence projection. */
export type PersonnelOrderEditorialReviewStatus =
  | "CURRENT"
  | "STALE"
  | "REVIEW_REQUIRED"
  | "GENERATION_FAILED";

export type PersonnelOrderEditorialBlock = {
  block_id: number;
  scope: "order" | "item" | string;
  order_item_id?: number | null;
  locale: "kk" | "ru" | string;
  block_type: "title" | "preamble" | "closing" | "body" | "basis" | string;
  generated_text?: string | null;
  override_text?: string | null;
  effective_text: string;
  suppressed?: boolean;
  generator_key?: string | null;
  generator_version?: string | null;
  source_fingerprint?: string | null;
  review_status: PersonnelOrderEditorialReviewStatus | string;
  basis_required?: boolean | null;
  editable: boolean;
  revision: number;
  generated_at?: string | null;
  edited_at?: string | null;
  edited_by_user_id?: number | null;
};

export type PersonnelOrderEditorialItemGroup = {
  order_item_id: number;
  item_number: number;
  item_type_code: string;
  basis_required: boolean;
  blocks: PersonnelOrderEditorialBlock[];
};

export type PersonnelOrderEditorialState = {
  order_id: number;
  order_status: string;
  editable: boolean;
  order_blocks: PersonnelOrderEditorialBlock[];
  items: PersonnelOrderEditorialItemGroup[];
};

export type PersonnelOrdersFilters = {
  status?: PersonnelOrderStatus | string;
  order_type_code?: PersonnelOrderType | string;
  date_from?: string;
  date_to?: string;
  employee_id?: number;
  org_unit_id?: number;
  order_id?: number;
  q?: string;
  record_quality?: "WORKING" | "TECHNICAL" | "ALL";
  reconstruction_quality?: "NEEDS_DOCX_REVIEW" | "RECONSTRUCTED_PILOT";
  include_closed?: boolean;
  limit?: number;
  offset?: number;
};

export type PersonnelOrderCreatePayload = {
  order_type_code: string;
  order_number?: string | null;
  order_date?: string | null;
  source_mode?: string;
  legal_basis_article?: string | null;
  signed_by_employee_id?: number | null;
  signed_by_name?: string | null;
  signed_by_position?: string | null;
  executor_name?: string | null;
  basis_summary?: string | null;
  comment?: string | null;
};

export type PersonnelOrderManualDraftCreatePayload = {
  template_version_id?: number;
  order_number: string;
  order_date: string;
  source_title: string;
  source_title_locale: "kk" | "ru";
  item_type_code: string;
  employee_id?: number | null;
  document_subject_context?: {
    org_unit_name?: string | null;
    position_name?: string | null;
    specialty?: string | null;
    rate?: string | null;
    basis_type?: "PERSONAL_APPLICATION" | "OTHER" | null;
  };
  unresolved_subject?: {
    full_name: string;
    org_unit_name: string;
    position_name: string;
    specialty: string;
  };
  effective_date: string;
  period_start?: string | null;
  period_end?: string | null;
  item_payload?: Record<string, unknown>;
};

export type PersonnelOrderManualDraftCreateResult = {
  order_id: number;
  order_number: string;
  order_type_code: string;
  status: "DRAFT";
  source_mode: "MANUAL";
  document_revision: number;
  document_review_state: "NEEDS_REVIEW";
};

export type PersonnelOrderUpdatePayload = {
  order_number?: string;
  order_date?: string;
  order_type_code?: string;
  source_mode?: string;
  legal_basis_article?: string | null;
  signed_by_employee_id?: number | null;
  signed_by_name?: string | null;
  signed_by_position?: string | null;
  executor_name?: string | null;
  basis_summary?: string | null;
  comment?: string | null;
};

export type PersonnelOrderSignatoryDefault = {
  signed_by_employee_id?: number | null;
  signed_by_name?: string | null;
  signed_by_position?: string | null;
  warning?: string | null;
  source?: string | null;
};

export type PersonnelOrderItemCreatePayload = {
  item_type_code: string;
  employee_id?: number | null;
  effective_date?: string | null;
  period_start?: string | null;
  period_end?: string | null;
  payload?: Record<string, unknown>;
  item_number?: number;
};

export type PersonnelOrderItemUpdatePayload = {
  item_type_code?: string;
  employee_id?: number | null;
  effective_date?: string | null;
  period_start?: string | null;
  period_end?: string | null;
  payload?: Record<string, unknown>;
  item_number?: number;
};

export const PERSONNEL_ORDERS_BASE_PATH = "/directory/personnel/orders";

function getDevUserId(): string | null {
  const appEnv = (process.env.NEXT_PUBLIC_APP_ENV || "dev").trim().toLowerCase();
  if (appEnv === "prod" || appEnv === "production") return null;
  const v = (process.env.NEXT_PUBLIC_DEV_X_USER_ID || "").trim();
  return v ? v : null;
}

function authHeaders(): Record<string, string> {
  const extra: Record<string, string> = { Accept: "application/json" };
  const devUserId = getDevUserId();
  if (devUserId) extra["X-User-Id"] = devUserId;
  return buildHeaders(extra) as Record<string, string>;
}

function parseErrorBody(status: number, body: string, fallback: string): Error {
  if (status === 403) {
    return new Error("Недостаточно прав для работы с кадровыми приказами.");
  }
  const trimmed = body.trim();
  if (trimmed.startsWith("{")) {
    try {
      const parsed = JSON.parse(trimmed) as { detail?: unknown };
      if (typeof parsed.detail === "string" && parsed.detail.trim()) {
        return new Error(parsed.detail.trim());
      }
      if (parsed.detail && typeof parsed.detail === "object") {
        const detail = parsed.detail as { code?: unknown; message?: unknown };
        if (typeof detail.code === "string") {
          return new Error(`${detail.code}: ${typeof detail.message === "string" ? detail.message : ""}`.trim());
        }
      }
      if (Array.isArray(parsed.detail)) {
        const parts = parsed.detail
          .map((item) => {
            if (typeof item === "string") return item;
            if (item && typeof item === "object" && "msg" in item) {
              return String((item as { msg?: unknown }).msg || "");
            }
            return "";
          })
          .filter(Boolean);
        if (parts.length) return new Error(parts.join("; "));
      }
    } catch {
      // keep raw body fallback
    }
  }
  return new Error(trimmed || fallback || `HTTP ${status}`);
}

async function requestJson<T>(
  method: string,
  path: string,
  options?: { body?: unknown; fallback?: string },
): Promise<T> {
  const res = await fetch(resolveApiUrl(path), {
    method,
    headers: {
      ...authHeaders(),
      ...(options?.body !== undefined ? { "Content-Type": "application/json" } : {}),
    },
    body: options?.body !== undefined ? JSON.stringify(options.body) : undefined,
    cache: "no-store",
  });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw parseErrorBody(res.status, body, options?.fallback || "Ошибка запроса.");
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

export function mapPersonnelOrdersApiError(e: unknown, fallback = "Ошибка запроса."): string {
  return formatThrownError(e, { fallback });
}

export function buildPersonnelOrdersQueryParams(
  filters: PersonnelOrdersFilters,
  options?: { includeClientSearch?: boolean; includeOrderIdInQuery?: boolean },
): URLSearchParams {
  const params = new URLSearchParams();
  const includeClientSearch = options?.includeClientSearch ?? true;

  if (filters.status?.trim()) params.set("status", filters.status.trim());
  if (filters.order_type_code?.trim()) params.set("order_type_code", filters.order_type_code.trim());
  if (filters.date_from?.trim()) params.set("date_from", filters.date_from.trim());
  if (filters.date_to?.trim()) params.set("date_to", filters.date_to.trim());
  if (filters.employee_id != null && filters.employee_id > 0) {
    params.set("employee_id", String(filters.employee_id));
  }
  if (filters.org_unit_id != null && filters.org_unit_id > 0) {
    params.set("org_unit_id", String(filters.org_unit_id));
  }
  // order_id is a UI deep-link only; not an API list filter.
  if (options?.includeOrderIdInQuery && filters.order_id != null && filters.order_id > 0) {
    params.set("order_id", String(filters.order_id));
  }
  if (includeClientSearch && filters.q?.trim()) params.set("q", filters.q.trim());
  if (filters.record_quality) params.set("record_quality", filters.record_quality);
  if (filters.reconstruction_quality) params.set("reconstruction_quality", filters.reconstruction_quality);
  if (filters.include_closed) params.set("include_closed", "true");
  if (filters.limit != null && filters.limit > 0) params.set("limit", String(filters.limit));
  if (filters.offset != null && filters.offset >= 0) params.set("offset", String(filters.offset));

  return params;
}

export function parsePersonnelOrdersFilters(searchParams: URLSearchParams): PersonnelOrdersFilters {
  const employeeId = Number(searchParams.get("employee_id"));
  const orderId = Number(searchParams.get("order_id"));
  const orgFilters = readTaskOrgFiltersFromSearchParams(searchParams);

  return {
    status: searchParams.get("status") || undefined,
    order_type_code: searchParams.get("order_type_code") || undefined,
    date_from: searchParams.get("date_from") || undefined,
    date_to: searchParams.get("date_to") || undefined,
    employee_id: Number.isFinite(employeeId) && employeeId > 0 ? employeeId : undefined,
    org_unit_id: orgFilters.org_unit_id,
    order_id: Number.isFinite(orderId) && orderId > 0 ? orderId : undefined,
    q: searchParams.get("q") || undefined,
    record_quality: searchParams.get("record_quality") === "TECHNICAL" || searchParams.get("record_quality") === "ALL"
      ? searchParams.get("record_quality") as "TECHNICAL" | "ALL"
      : "WORKING",
    reconstruction_quality:
      searchParams.get("reconstruction_quality") === "NEEDS_DOCX_REVIEW"
      || searchParams.get("reconstruction_quality") === "RECONSTRUCTED_PILOT"
        ? searchParams.get("reconstruction_quality") as "NEEDS_DOCX_REVIEW" | "RECONSTRUCTED_PILOT"
        : undefined,
    include_closed:
      searchParams.get("include_closed") === "true"
      || searchParams.get("include_archived") === "true",
  };
}

export function buildPersonnelOrdersHref(filters: PersonnelOrdersFilters = {}): string {
  const qs = buildPersonnelOrdersQueryParams(filters, { includeOrderIdInQuery: true }).toString();
  return qs ? `${PERSONNEL_ORDERS_BASE_PATH}?${qs}` : PERSONNEL_ORDERS_BASE_PATH;
}

export function filterPersonnelOrdersBySearch(
  items: PersonnelOrderListItem[],
  query: string | undefined,
): PersonnelOrderListItem[] {
  const q = String(query || "")
    .trim()
    .toLowerCase();
  if (!q) return items;
  return items.filter((row) => {
    const number = String(row.order_number || "").toLowerCase();
    const title = String(row.source_title || "").toLowerCase();
    const names = (row.employee_names || []).join(" ").toLowerCase();
    const ids = (row.employee_ids || []).map(String).join(" ");
    const orderId = String(row.order_id);
    return number.includes(q) || title.includes(q) || names.includes(q) || ids.includes(q) || orderId.includes(q);
  });
}

export async function listPersonnelOrders(
  filters: PersonnelOrdersFilters = {},
): Promise<PersonnelOrdersListResponse> {
  const qs = buildPersonnelOrdersQueryParams(filters, { includeClientSearch: true }).toString();
  const url = resolveApiUrl(`/directory/personnel-orders${qs ? `?${qs}` : ""}`);
  const res = await fetch(url, { method: "GET", headers: authHeaders(), cache: "no-store" });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw parseErrorBody(res.status, body, "Не удалось загрузить журнал приказов.");
  }
  return res.json() as Promise<PersonnelOrdersListResponse>;
}

export async function getPersonnelOrder(orderId: number): Promise<PersonnelOrderDetailResponse> {
  return requestJson<PersonnelOrderDetailResponse>("GET", `/directory/personnel-orders/${orderId}`, {
    fallback: "Не удалось загрузить приказ.",
  });
}

export async function getPersonnelOrderDeletedTombstone(orderId: number): Promise<PersonnelOrderDeletedTombstone> {
  return requestJson<PersonnelOrderDeletedTombstone>("GET", `/directory/personnel-orders/${orderId}/deleted-tombstone`, {
    fallback: "Не удалось загрузить сведения об удалённом приказе.",
  });
}

export async function getPersonnelOrderDocumentReview(orderId: number): Promise<PersonnelOrderDocumentReview> {
  return requestJson("GET", `/directory/personnel-orders/${orderId}/document-review`, { fallback: "Не удалось загрузить проверку документа." });
}

export async function confirmPersonnelOrderDocumentReview(orderId: number, payload: { expected_document_revision: number; reason_code: string; note?: string }) {
  return requestJson<PersonnelOrderDocumentReview>("POST", `/directory/personnel-orders/${orderId}/document-review/confirm`, { body: payload, fallback: "Не удалось подтвердить документ." });
}

export async function reopenPersonnelOrderDocumentReview(orderId: number, payload: { expected_document_revision: number; reason_code: string; note: string }) {
  return requestJson<PersonnelOrderDocumentReview>("POST", `/directory/personnel-orders/${orderId}/document-review/reopen`, { body: payload, fallback: "Не удалось вернуть документ на проверку." });
}
export async function previewPersonnelOrderHeaderDuplicate(payload: { order_id?: number; order_number: string; order_date?: string | null }): Promise<PersonnelOrderHeaderDuplicatePreview> {
  return requestJson("POST", "/directory/personnel-orders/header-duplicate-preview", { body: payload, fallback: "Не удалось проверить дубликат." });
}
export async function patchPersonnelOrderDocumentHeader(orderId: number, payload: { expected_document_revision: number; order_number: string; order_date?: string | null; source_title?: string | null; source_title_locale?: "kk" | "ru" | "unknown" | null; reason_code?: string | null; reason_text?: string | null }) {
  return requestJson("PATCH", `/directory/personnel-orders/${orderId}/document-header`, { body: payload, fallback: "Не удалось сохранить реквизиты документа." });
}
export type PersonnelOrderDocumentItemPatchResult = {
  no_op: boolean;
  resulting_document_revision: number;
  header_type_code?: string;
  document_review_state?: "NEEDS_REVIEW" | null;
  audit_event_ids: number[];
};

export async function patchPersonnelOrderDocumentItem(orderId: number, itemId: number, payload: { expected_document_revision: number; item_type_code: string; employee_id?: number | null; effective_date?: string | null; document_subject_context?: { recall_position_kk?: string | null; recall_org_unit_kk?: string | null; basis_ru?: string | null; basis_kk?: string | null; position_name?: string | null; org_unit_name?: string | null; specialty?: string | null; rate?: string | null; basis_type?: "PERSONAL_APPLICATION" | "OTHER" | null }; reason_code?: string | null; reason_text?: string | null }): Promise<PersonnelOrderDocumentItemPatchResult> {
  return requestJson<PersonnelOrderDocumentItemPatchResult>("PATCH", `/directory/personnel-orders/${orderId}/document-items/${itemId}`, { body: payload, fallback: "Не удалось сохранить пункт." });
}
export type PersonnelOrderDocumentItem = { recall_position_kk?: string | null; recall_org_unit_kk?: string | null; basis_ru?: string | null; basis_kk?: string | null; item_id: number; item_number: number; item_type_code: string; employee_id?: number | null; employee_name?: string | null; org_unit_name?: string | null; position_name?: string | null; specialty?: string | null; rate?: string | null; needs_employee_link?: boolean; effective_date?: string | null };
export async function listPersonnelOrderDocumentItems(orderId: number): Promise<{ document_revision: number; items: PersonnelOrderDocumentItem[] }> {
  return requestJson("GET", `/directory/personnel-orders/${orderId}/document-items`, { fallback: "Не удалось загрузить пункты приказа." });
}

export async function listPersonnelOrderAcknowledgements(orderId: number): Promise<{ items: PersonnelOrderAcknowledgement[] }> {
  return requestJson("GET", `/directory/personnel-orders/${orderId}/acknowledgements`, { fallback: "Не удалось загрузить ознакомление." });
}

export async function recordPersonnelOrderAcknowledgement(orderId: number, employeeId: number, acknowledgedOn: string) {
  return requestJson("POST", `/directory/personnel-orders/${orderId}/acknowledgements`, {
    body: { employee_id: employeeId, acknowledged_on: acknowledgedOn }, fallback: "Не удалось зарегистрировать ознакомление.",
  });
}

export async function clearPersonnelOrderAcknowledgement(orderId: number, employeeId: number) {
  return requestJson("POST", `/directory/personnel-orders/${orderId}/acknowledgements/clear`, {
    body: { employee_id: employeeId }, fallback: "Не удалось очистить ознакомление.",
  });
}

export async function getPersonnelOrderEditorial(
  orderId: number,
): Promise<PersonnelOrderEditorialState> {
  return requestJson<PersonnelOrderEditorialState>(
    "GET",
    `/directory/personnel-orders/${orderId}/editorial`,
    { fallback: "Не удалось загрузить редакционные блоки приказа." },
  );
}

export async function generatePersonnelOrderEditorial(
  orderId: number,
  scope?: {
    locale?: string;
    item_id?: number;
    block_id?: number;
    block_type?: string;
  },
): Promise<PersonnelOrderEditorialState> {
  return requestJson<PersonnelOrderEditorialState>(
    "POST",
    `/directory/personnel-orders/${orderId}/editorial/generate`,
    {
      body: scope ?? {},
      fallback: "Не удалось сформировать текст приказа.",
    },
  );
}

export async function patchPersonnelOrderEditorialBlock(
  orderId: number,
  blockId: number,
  payload: {
    override_text?: string | null;
    clear_override?: boolean;
    expected_revision?: number;
  },
): Promise<PersonnelOrderEditorialState> {
  return requestJson<PersonnelOrderEditorialState>(
    "PATCH",
    `/directory/personnel-orders/${orderId}/editorial/blocks/${blockId}`,
    {
      body: payload,
      fallback: "Не удалось сохранить текст блока.",
    },
  );
}

export async function resetPersonnelOrderEditorialBlock(
  orderId: number,
  blockId: number,
): Promise<PersonnelOrderEditorialState> {
  return requestJson<PersonnelOrderEditorialState>(
    "POST",
    `/directory/personnel-orders/${orderId}/editorial/blocks/${blockId}/reset-to-generated`,
    { fallback: "Не удалось вернуть автоматически сформированный текст." },
  );
}

export async function createPersonnelOrder(
  payload: PersonnelOrderCreatePayload,
): Promise<PersonnelOrderDetailResponse> {
  return requestJson<PersonnelOrderDetailResponse>("POST", "/directory/personnel-orders", {
    body: payload,
    fallback: "Не удалось создать приказ.",
  });
}

export type PersonnelOrderTemplateApplicationBlock = {
  block_id: number;
  scope: "ORDER" | "ITEM";
  block_type: "TITLE" | "PREAMBLE" | "BODY" | "BASIS";
  language: "RU" | "KK";
  order_item_id: number | null;
};
export type PersonnelOrderTemplateApplicationCurrentBlock = {
  block_id?: number;
  scope?: "ORDER" | "ITEM";
  order_item_id?: number | null;
  locale?: "ru" | "kk";
  block_type?: "title" | "preamble" | "body" | "basis";
  generated_text?: string | null;
  override_text?: string | null;
  revision?: number;
};
export type PersonnelOrderTemplateApplicationPreview = {
  available: boolean;
  template: { template_version_id: number; version_number: number; item_type_code: string };
  has_overrides: boolean;
  override_blocks: PersonnelOrderTemplateApplicationBlock[];
  has_prior_application: boolean;
  last_application: { application_id: number; template_version_id: number; template_version_number: number; applied_at: string; applied_by_user_id: number } | null;
  current?: Record<string, PersonnelOrderTemplateApplicationCurrentBlock>;
  proposed?: Record<string, string>;
  order_current?: Record<string, PersonnelOrderTemplateApplicationCurrentBlock>;
  order_proposed?: Record<string, string>;
  items?: Array<{ order_item_id: number; item_number: number; current: Record<string, PersonnelOrderTemplateApplicationCurrentBlock>; proposed: Record<string, string>; warnings: Array<{ code: string; message: string }>; missing_data: string[] }>;
  order_revision: number;
};
export const previewPersonnelOrderTemplateApplication = (orderId: number) => requestJson<PersonnelOrderTemplateApplicationPreview>("GET", `/directory/personnel-orders/${orderId}/template-application/preview`, { fallback: "Не удалось подготовить сравнение шаблона." });
export const applyPersonnelOrderTemplateApplication = (orderId: number, body: { expected_document_revision: number; confirm_replace_overrides: boolean; confirm_reapply: boolean }) => requestJson<PersonnelOrderEditorialState>("POST", `/directory/personnel-orders/${orderId}/template-application`, { body, fallback: "Не удалось применить шаблон." });

export async function createManualPersonnelOrderDraft(
  payload: PersonnelOrderManualDraftCreatePayload,
): Promise<PersonnelOrderManualDraftCreateResult> {
  return requestJson("POST", "/directory/personnel-orders/manual-draft", {
    body: payload,
    fallback: "Не удалось создать приказ.",
  });
}

export async function getPersonnelOrderPublishedTemplateTitle(itemTypeCode: string, versionId?: number): Promise<{ template_version_id?: number; item_type_code: string; title_ru: string; title_kk: string }> {
  return requestJson("GET", `/directory/personnel-orders/templates/${encodeURIComponent(itemTypeCode)}/published-title${versionId == null ? "" : `?template_version_id=${versionId}`}`, {
    fallback: "Опубликованный шаблон не найден.",
  });
}

export async function getPersonnelOrderSignatoryDefault(): Promise<PersonnelOrderSignatoryDefault> {
  return requestJson<PersonnelOrderSignatoryDefault>(
    "GET",
    "/directory/personnel-orders/signatory-default",
    {
      fallback: "Не удалось определить подписанта по умолчанию.",
    },
  );
}

export async function updatePersonnelOrder(
  orderId: number,
  payload: PersonnelOrderUpdatePayload,
): Promise<PersonnelOrderDetailResponse> {
  return requestJson<PersonnelOrderDetailResponse>("PATCH", `/directory/personnel-orders/${orderId}`, {
    body: payload,
    fallback: "Не удалось обновить приказ.",
  });
}

export async function createPersonnelOrderItem(
  orderId: number,
  payload: PersonnelOrderItemCreatePayload,
): Promise<PersonnelOrderDetailResponse> {
  return requestJson<PersonnelOrderDetailResponse>("POST", `/directory/personnel-orders/${orderId}/items`, {
    body: payload,
    fallback: "Не удалось добавить пункт приказа.",
  });
}

export async function updatePersonnelOrderItem(
  orderId: number,
  itemId: number,
  payload: PersonnelOrderItemUpdatePayload,
): Promise<PersonnelOrderDetailResponse> {
  return requestJson<PersonnelOrderDetailResponse>(
    "PATCH",
    `/directory/personnel-orders/${orderId}/items/${itemId}`,
    {
      body: payload,
      fallback: "Не удалось обновить пункт приказа.",
    },
  );
}

export async function deletePersonnelOrderItem(
  orderId: number,
  itemId: number,
): Promise<PersonnelOrderDetailResponse> {
  return requestJson<PersonnelOrderDetailResponse>(
    "DELETE",
    `/directory/personnel-orders/${orderId}/items/${itemId}`,
    { fallback: "Не удалось удалить пункт приказа." },
  );
}

export type PersonnelOrderDraftDeletionPreview = {
  can_delete: boolean;
  confirmation_phrase: string;
  planned_deletions: Array<{ table: string; count: number }>;
  retained: string[];
  blocking_dependencies: Array<{ table: string; count: number }>;
};

export async function getPersonnelOrderDraftDeletionPreview(orderId: number): Promise<PersonnelOrderDraftDeletionPreview> {
  return requestJson<PersonnelOrderDraftDeletionPreview>("GET", `/directory/personnel-orders/${orderId}/draft-deletion-preview`);
}

export async function deletePersonnelOrderDraft(orderId: number, payload: { reason: string; confirmation_phrase: string }): Promise<{ status: string; order_id: number }> {
  return requestJson<{ status: string; order_id: number }>("DELETE", `/directory/personnel-orders/${orderId}`, { body: payload });
}

export async function deletePersonnelOrderAsHrHead(orderId: number): Promise<{ status: string; order_id: number }> {
  const path = `/directory/personnel-orders/${orderId}/hr-head`;
  const res = await fetch(resolveApiUrl(path), { method: "DELETE", headers: authHeaders(), cache: "no-store" });
  if (res.ok) return res.json() as Promise<{ status: string; order_id: number }>;
  if (res.status === 404) {
    const detail = await fetch(resolveApiUrl(`/directory/personnel-orders/${orderId}`), { headers: authHeaders(), cache: "no-store" });
    if (detail.status === 404) return { status: "ALREADY_DELETED", order_id: orderId };
  }
  throw parseErrorBody(res.status, await res.text().catch(() => ""), "Не удалось удалить приказ.");
}

export async function markPersonnelOrderReadyForSignature(
  orderId: number,
): Promise<PersonnelOrderDetailResponse> {
  return requestJson<PersonnelOrderDetailResponse>(
    "POST",
    `/directory/personnel-orders/${orderId}/ready-for-signature`,
    { fallback: "Не удалось перевести приказ в статус «На подписи»." },
  );
}

export async function registerPersonnelOrder(
  orderId: number,
  targetStatus: "REGISTERED" | "SIGNED" = "REGISTERED",
): Promise<PersonnelOrderDetailResponse> {
  return requestJson<PersonnelOrderDetailResponse>(
    "POST",
    `/directory/personnel-orders/${orderId}/register`,
    {
      body: { target_status: targetStatus },
      fallback: "Не удалось зарегистрировать приказ.",
    },
  );
}

export async function applyPersonnelOrder(orderId: number): Promise<PersonnelOrderDetailResponse> {
  return requestJson<PersonnelOrderDetailResponse>(
    "POST",
    `/directory/personnel-orders/${orderId}/apply`,
    { fallback: "Не удалось применить приказ." },
  );
}

export async function voidPersonnelOrder(
  orderId: number,
  voidReason: string,
): Promise<PersonnelOrderDetailResponse> {
  return requestJson<PersonnelOrderDetailResponse>("POST", `/directory/personnel-orders/${orderId}/void`, {
    body: { void_reason: voidReason },
    fallback: "Не удалось аннулировать приказ.",
  });
}

export type PersonnelOrderArchivePayload = {
  reason_code: "completed" | "voided_record" | "migrated_legacy" | "duplicate_reference" | "other";
  reason_text?: string;
};

export async function archivePersonnelOrder(
  orderId: number,
  payload: PersonnelOrderArchivePayload,
): Promise<PersonnelOrderDetailResponse> {
  return requestJson<PersonnelOrderDetailResponse>("POST", `/directory/personnel-orders/${orderId}/archive`, {
    body: payload,
    fallback: "Не удалось архивировать приказ.",
  });
}

export async function restorePersonnelOrder(orderId: number): Promise<PersonnelOrderDetailResponse> {
  return requestJson<PersonnelOrderDetailResponse>("POST", `/directory/personnel-orders/${orderId}/restore`, {
    body: {},
    fallback: "Не удалось восстановить приказ.",
  });
}

export type PersonnelPublishedTemplateVariant = {template_id: number; template_version_id: number; version_number: number; name_ru: string; name_kk: string; title_ru: string; title_kk: string; is_default: boolean};
export const getPersonnelOrderPublishedVariants = (type: string) => requestJson<{items: PersonnelPublishedTemplateVariant[]}>("GET", `/directory/personnel-orders/templates/${encodeURIComponent(type)}/published-variants`, {fallback: "Не удалось загрузить варианты шаблона."});
