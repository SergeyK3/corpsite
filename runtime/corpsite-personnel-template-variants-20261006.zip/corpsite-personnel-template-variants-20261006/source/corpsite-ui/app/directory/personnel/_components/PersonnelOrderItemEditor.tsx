"use client";

import * as React from "react";

import { getEmployee, getEmployees } from "@/app/directory/employees/_lib/api.client";
import OrgScopeFilter from "@/components/OrgScopeFilter";
import OrgUnitScopeFilter from "@/components/OrgUnitScopeFilter";
import {
  isOrgUnitAllowedForGroup,
  isPositionAllowedInOptions,
  type PersonnelOrderPositionSelectGroup,
} from "@/lib/taskOrgFilters";
import { useOrgUnitScopeOptions } from "@/lib/useOrgUnitScopeOptions";
import { usePersonnelOrderPositionOptions } from "@/lib/usePersonnelOrderPositionOptions";
import { HR_DOSSIER_TITLE } from "@/lib/personnelCardTerminology";
import { resolveEmployeeOrgScopePrefill } from "@/lib/userCreateOrgScope";

import {
  createPersonnelOrderItem,
  deletePersonnelOrderItem,
  mapPersonnelOrdersApiError,
  updatePersonnelOrderItem,
  type PersonnelOrderDetailResponse,
  type PersonnelOrderItem,
} from "../_lib/personnelOrdersApi.client";
import { getPprHireDefaultsByPersonId } from "../_lib/pprQueryApi.client";
import {
  employeeDtoToSearchOption,
  resolveCurrentPlacementView,
  type CurrentPlacementView,
} from "../_lib/personnelOrderCurrentPlacement";
import { resolvePersonnelOrderDocumentForms, resolvePersonnelOrderOrgUnitForms, savedKazakhEmployeeNameForm } from "../_lib/personnelOrderDocumentForms";
import { calculateKazakhOrgUnitGenitive, calculateKazakhPersonForm, firstNonEmpty } from "../_lib/kazakhDocumentForms";
import { russianEmployeeGenitiveForOrder, savedRussianEmployeeNameForm } from "../_lib/personnelOrderRussianWording";
import {
  mapEmployeesResponseToSearchOptions,
  requireEmployeeIdForItemType,
  type EmployeeSearchOption,
} from "../_lib/personnelOrderEmployeeSearch";
import {
  allowsPendingNewEmployee,
  detectUiItemTypeFromRecord,
  getItemFormRegistry,
  itemFormTypeLabel,
  itemFormTypeOptionsForOrder,
  normalizeItemFormType,
  orderTypeLabelForItemHint,
  resolveDefaultItemFormTypeForOrder,
  resolveBackendItemTypeCode,
  requiresEmployeeForFormType,
  type ItemFormSection,
  type PersonnelOrderItemFormType,
  usesActiveEmployeeSearch,
} from "../_lib/personnelOrderItemFormRegistry";
import {
  buildItemPayload,
  emptyItemPayloadDraft,
  itemPayloadDraftFromRecord,
  type ItemPayloadDraft,
} from "../_lib/personnelOrderPayload";
import {
  clearOrgDependentFields,
  clearTransferTargetFields,
  isOrgScopedItemType,
  selectedOrgUnitIdFromDraft,
  selectedPositionIdFromDraft,
  setOrgUnitAndClearPosition,
  setPositionId,
} from "../_lib/personnelOrderOrgScope";

type Props = {
  orderId: number;
  orderTypeCode?: string | null;
  items: PersonnelOrderItem[];
  disabled?: boolean;
  onChanged: (detail: PersonnelOrderDetailResponse) => void;
  /** Applicant person_id for HIRE without pre-existing employee. */
  hirePersonId?: number | null;
  basisDocuments?: Array<{ basis_id?: unknown; document_type?: unknown; description?: unknown }>;
  registerPendingSave?: (save: (() => Promise<boolean>) | null) => void;
};

const BASIS_TYPE_LABELS: Record<string, string> = {
  EMPLOYEE_APPLICATION: "Заявление работника / Қызметкердің жеке өтініші",
  SERVICE_MEMO: "Служебная записка / Қызметтік хат",
  REPORT_MEMO: "Докладная записка / Баяндау хат",
  EMPLOYMENT_CONTRACT: "Трудовой договор / Еңбек шарты",
  MEDICAL_CERTIFICATE: "Медицинская справка / Медициналық анықтама",
  PREVIOUS_ORDER: "Предыдущий приказ / Алдыңғы бұйрық",
  COLLECTIVE_AGREEMENT: "Коллективный договор / Ұжымдық шарт",
};

function basisTypeLabel(documentType: string): string {
  return BASIS_TYPE_LABELS[documentType] || documentType;
}

function sourceEmployeeName(item: PersonnelOrderItem): string {
  if (item.employee_name) return item.employee_name;
  if (item.employee_id) return `#${item.employee_id}`;
  const employee = item.payload?.employee;
  if (employee && typeof employee === "object") {
    const name = (employee as Record<string, unknown>).name;
    if (name && typeof name === "object") {
      const canonical = (name as Record<string, unknown>).canonical;
      if (typeof canonical === "string" && canonical.trim()) return canonical.trim();
    }
  }
  return "Не указан";
}

function explicitEmployeeKkNameForm(employee: unknown, field: "employee_full_name_dative_kk" | "employee_full_name_genitive_kk"): string {
  return savedKazakhEmployeeNameForm(employee, field === "employee_full_name_genitive_kk" ? "genitive" : "dative");
}

function persistedEffectiveDate(item: PersonnelOrderItem): string {
  const payloadDate = item.payload?.effective_date;
  const value = item.effective_date ?? (typeof payloadDate === "string" ? payloadDate : null);
  // A date input only accepts YYYY-MM-DD. Do not fall back to the order date:
  // the item date is a separate personnel record and may genuinely be absent.
  return typeof value === "string" ? value.slice(0, 10) : "";
}

function hasPersonalApplicationBasis(
  payload: Record<string, unknown>,
  basisDocuments: Array<{ basis_id?: unknown; document_type?: unknown; description?: unknown }>,
): boolean {
  const basis = payload.basis;
  if (basis && typeof basis === "object" && String((basis as Record<string, unknown>).kind || "").toUpperCase() === "PERSONAL_APPLICATION") return true;
  if (String(payload.basis_type || "").toUpperCase() === "PERSONAL_APPLICATION") return true;
  const linkedIds = Array.isArray(payload.basis_ids) ? payload.basis_ids.map(String) : [];
  const entryTypes = Array.isArray(payload.basis_entries)
    ? payload.basis_entries.map((entry) => String((entry as Record<string, unknown>)?.document_type || ""))
    : [];
  return [...entryTypes, ...basisDocuments
    .filter((document) => linkedIds.includes(String(document.basis_id || "")))
    .map((document) => String(document.document_type || ""))]
    .some((type) => ["PERSONAL_APPLICATION", "EMPLOYEE_APPLICATION"].includes(type.toUpperCase()));
}

function assignmentSummary(value: unknown): string | null {
  if (!value || typeof value !== "object") return null;
  const assignment = value as Record<string, unknown>;
  const label = (part: unknown): string | null => {
    if (!part || typeof part !== "object") return null;
    const item = part as Record<string, unknown>;
    for (const key of ["kk", "ru", "text"]) {
      const candidate = item[key];
      if (typeof candidate === "string" && candidate.trim()) return candidate.trim();
    }
    return null;
  };
  const values = [label(assignment.unit), label(assignment.position)];
  const rate = assignment.rate;
  if (typeof rate === "string" && rate.trim()) values.push(`${rate.trim()} ставка`);
  return values.filter(Boolean).join(" · ") || null;
}

function sourceItemSummary(item: PersonnelOrderItem): string {
  const payload = item.payload || {};
  const summaries = [
    assignmentSummary(payload.assignment),
    assignmentSummary(payload.to_assignment),
    typeof payload.termination_reason === "string" ? payload.termination_reason : null,
    typeof payload.concurrent_rate === "string" ? `Ставка: ${payload.concurrent_rate}` : null,
    typeof payload.remaining_rate === "string" ? `Остающаяся ставка: ${payload.remaining_rate}` : null,
    typeof payload.removed_rate === "string" ? `Снимаемая ставка: ${payload.removed_rate}` : null,
  ].filter((value): value is string => Boolean(value && value.trim()));
  return summaries.join("; ") || "—";
}

const ORG_SCOPE_BASE_PATH = "/directory/personnel/orders";

const FIELD_LABEL_CLASS = "mb-1 block text-sm font-medium text-zinc-800 dark:text-zinc-200";
const FIELD_INPUT_CLASS =
  "w-full rounded-lg border border-zinc-300 bg-white px-3 py-2 text-sm dark:border-zinc-700 dark:bg-zinc-950";
const FIELD_HINT_CLASS = "mt-1 text-xs text-zinc-500 dark:text-zinc-400";

function unpaidPeriodClauseKk(draft: ItemPayloadDraft): string {
  const months = ["қаңтар", "ақпан", "наурыз", "сәуір", "мамыр", "маусым", "шілде", "тамыз", "қыркүйек", "қазан", "қараша", "желтоқсан"];
  const parse = (raw: string) => {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(raw);
    return match ? { year: Number(match[1]), month: Number(match[2]), day: Number(match[3]) } : null;
  };
  const start = parse(String(draft.leave_start || ""));
  const end = parse(String(draft.leave_end || ""));
  const dayMonth = (value: { month: number; day: number }) => `${value.day} ${months[value.month - 1]}`;
  if (start && end && start.year === end.year && start.month === end.month && start.day === end.day) return `${start.year} жылғы ${dayMonth(start)} күніне`;
  if (start && end) {
    if (start.year === end.year && start.month === end.month) return `${start.year} жылғы ${start.day} мен ${end.day} ${months[start.month - 1]} аралығында`;
    return `${start.year} жылғы ${dayMonth(start)} мен ${end.year === start.year ? "" : `${end.year} жылғы `}${dayMonth(end)} аралығында`;
  }
  return "…";
}

function placementValue(value: string | null | undefined): string {
  const text = String(value ?? "").trim();
  return text || "—";
}

function renderPersonnelOrderPositionOptions(
  groups: readonly PersonnelOrderPositionSelectGroup[],
) {
  if (groups.length === 0) return null;

  return groups.map((group) => (
    <optgroup key={group.key} label={group.label}>
      {group.items.map((position) => (
        <option key={position.id} value={String(position.id)}>
          {position.label}
        </option>
      ))}
    </optgroup>
  ));
}

function FormField({
  label,
  htmlFor,
  hint,
  children,
  className = "",
}: {
  label: string;
  htmlFor?: string;
  hint?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <label htmlFor={htmlFor} className={FIELD_LABEL_CLASS}>
        {label}
      </label>
      {children}
      {hint ? <p className={FIELD_HINT_CLASS}>{hint}</p> : null}
    </div>
  );
}

function CurrentPlacementPanel({ placement }: { placement: CurrentPlacementView }) {
  return (
    <div
      className="space-y-2 rounded-lg border border-zinc-200 bg-zinc-50 p-3 dark:border-zinc-800 dark:bg-zinc-900/40"
      data-testid="personnel-order-current-placement"
    >
      <div className="text-xs font-semibold uppercase tracking-wide text-zinc-500">
        Текущее назначение
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        <div>
          <div className="text-[11px] text-zinc-500">Группа отделений</div>
          <div data-testid="personnel-order-current-org-group">
            {placementValue(placement.org_group_name)}
          </div>
        </div>
        <div>
          <div className="text-[11px] text-zinc-500">Подразделение</div>
          <div data-testid="personnel-order-current-org-unit">
            {placementValue(placement.org_unit_name)}
          </div>
        </div>
        <div>
          <div className="text-[11px] text-zinc-500">Должность</div>
          <div data-testid="personnel-order-current-position">
            {placementValue(placement.position_name)}
          </div>
        </div>
        <div>
          <div className="text-[11px] text-zinc-500">Ставка</div>
          <div data-testid="personnel-order-current-rate">{placementValue(placement.rate)}</div>
        </div>
      </div>
    </div>
  );
}

export default function PersonnelOrderItemEditor({
  orderId,
  orderTypeCode = null,
  items,
  disabled = false,
  onChanged,
  hirePersonId = null,
  basisDocuments = [],
  registerPendingSave,
}: Props) {
  const defaultItemType = resolveDefaultItemFormTypeForOrder(orderTypeCode);
  const itemTypeOptions = itemFormTypeOptionsForOrder(orderTypeCode);
  const orderTypeHint = orderTypeLabelForItemHint(orderTypeCode);

  const [editingItemId, setEditingItemId] = React.useState<number | null>(null);
  /** Saved employee_id when edit started; independent of current form fields (WP-PO-UX-001A). */
  const [editingItemSavedEmployeeId, setEditingItemSavedEmployeeId] = React.useState<number | null>(
    null,
  );
  const [itemTypeCode, setItemTypeCode] = React.useState<PersonnelOrderItemFormType>(defaultItemType);
  const [employeeId, setEmployeeId] = React.useState("");
  const [employeeQuery, setEmployeeQuery] = React.useState("");
  // An existing historical item can reference an employee who is no longer
  // returned by the active-only employee search.
  const [selectedEmployeeId, setSelectedEmployeeId] = React.useState<number | null>(null);
  const [changingEmployee, setChangingEmployee] = React.useState(false);
  const [pendingNewEmployee, setPendingNewEmployee] = React.useState(false);
  const [employeeOptions, setEmployeeOptions] = React.useState<EmployeeSearchOption[]>([]);
  const [currentPlacement, setCurrentPlacement] = React.useState<CurrentPlacementView | null>(null);
  const [deletingItemId, setDeletingItemId] = React.useState<number | null>(null);
  const deletionInProgressRef = React.useRef(false);
  const [leavePreviewLocale, setLeavePreviewLocale] = React.useState<"ru" | "kk">("ru");
  const [saveNotice, setSaveNotice] = React.useState<string | null>(null);
  const savedFormSignature = React.useRef<string | null>(null);
  const itemSaveInFlight = React.useRef<Promise<boolean> | null>(null);
  const [effectiveDate, setEffectiveDate] = React.useState("");
  const [payloadDraft, setPayloadDraft] = React.useState<ItemPayloadDraft>(emptyItemPayloadDraft());
  const [calculatedKkFields, setCalculatedKkFields] = React.useState<Set<string>>(() => new Set());
  const [terminationReasonSuggested, setTerminationReasonSuggested] = React.useState(false);
  const [editingBasis, setEditingBasis] = React.useState(false);
  const [targetOrgGroupId, setTargetOrgGroupId] = React.useState<number | null>(null);
  const [hireOrgGroupId, setHireOrgGroupId] = React.useState<number | null>(null);
  const [saving, setSaving] = React.useState(false);
  const [employeeSearchError, setEmployeeSearchError] = React.useState<string | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const employeeSelectionRevision = React.useRef(0);
  const ruGenitiveEdited = React.useRef(false);
  const editedPositionForms = React.useRef(new Set<string>());

  React.useEffect(() => {
    if (hirePersonId == null || !Number.isFinite(hirePersonId) || hirePersonId <= 0) return;
    if (editingItemId != null) return;
    const isHireContext =
      orderTypeCode?.toUpperCase() === "HIRE" || defaultItemType === "HIRE";
    if (!isHireContext) return;
    setItemTypeCode("HIRE");
    setPendingNewEmployee(true);
    setPayloadDraft((prev) => ({
      ...prev,
      person_id: String(hirePersonId),
    }));
  }, [hirePersonId, orderTypeCode, defaultItemType, editingItemId]);

  React.useEffect(() => {
    if (itemTypeCode !== "HIRE") return;
    const personNumeric = Number(String(payloadDraft.person_id || "").trim());
    if (!Number.isFinite(personNumeric) || personNumeric <= 0) return;

    let cancelled = false;
    void getPprHireDefaultsByPersonId(personNumeric)
      .then((defaults) => {
        if (cancelled) return;
        if (defaults.org_group_id != null) setHireOrgGroupId(defaults.org_group_id);
        setPayloadDraft((prev) => ({
          ...prev,
          org_unit_id:
            defaults.org_unit_id != null ? String(defaults.org_unit_id) : prev.org_unit_id ?? "",
          position_id:
            defaults.position_id != null ? String(defaults.position_id) : prev.position_id ?? "",
          employment_rate:
            defaults.employment_rate != null
              ? String(defaults.employment_rate)
              : prev.employment_rate ?? "1",
        }));
      })
      .catch(() => {});

    return () => {
      cancelled = true;
    };
  }, [itemTypeCode, payloadDraft.person_id]);

  const formConfig = getItemFormRegistry(itemTypeCode);
  const orgScoped = isOrgScopedItemType(itemTypeCode);
  const activeOrgGroupId = formConfig?.showHirePlacement ? hireOrgGroupId : targetOrgGroupId;
  const {
    options: orgUnitSelectOptions,
    catalogOptions: orgUnitCatalogOptions,
    loading: orgUnitsLoading,
    error: orgUnitsError,
  } = useOrgUnitScopeOptions(orgScoped ? activeOrgGroupId : null);
  const selectedOrgUnitId = selectedOrgUnitIdFromDraft(payloadDraft, itemTypeCode);
  const {
    positionGroups,
    allOptions: positionOptions,
    loading: positionsLoading,
  } = usePersonnelOrderPositionOptions({
    enabled: orgScoped,
    orgUnitId: selectedOrgUnitId,
    orgGroupId: activeOrgGroupId,
  });
  const effectiveDateLabel =
    itemTypeCode.toUpperCase() === "TERMINATION" ? "Дата увольнения" : "Дата вступления в силу";
  const savedEmployeeIdBlocksPendingReset =
    editingItemId != null &&
    editingItemSavedEmployeeId != null &&
    Number.isFinite(editingItemSavedEmployeeId) &&
    editingItemSavedEmployeeId > 0;
  const pendingNewEmployeeAllowed =
    allowsPendingNewEmployee(itemTypeCode) && !savedEmployeeIdBlocksPendingReset;
  const showEmployeePicker =
    formConfig?.employeePicker && !(pendingNewEmployee && pendingNewEmployeeAllowed)
    && (!savedEmployeeIdBlocksPendingReset || changingEmployee);

  React.useEffect(() => {
    if (editingItemId != null) return;
    setItemTypeCode(defaultItemType);
  }, [defaultItemType, editingItemId]);

  React.useEffect(() => {
    if (!formConfig?.employeePicker || pendingNewEmployee) {
      setEmployeeOptions([]);
      setEmployeeSearchError(null);
      return;
    }
    const q = employeeQuery.trim();
    if (q.length < 2) {
      setEmployeeOptions([]);
      setEmployeeSearchError(null);
      return;
    }
    const activeOnly = usesActiveEmployeeSearch(itemTypeCode);
    let cancelled = false;
    const timer = window.setTimeout(() => {
      setEmployeeSearchError(null);
      void getEmployees({
        q,
        limit: 20,
        status: activeOnly ? "active" : "all",
      })
        .then((res) => {
          if (cancelled) return;
          setEmployeeOptions(mapEmployeesResponseToSearchOptions(res, { activeOnly }));
        })
        .catch((err) => {
          if (cancelled) return;
          setEmployeeOptions([]);
          setEmployeeSearchError(
            err instanceof Error ? err.message : "Не удалось загрузить список сотрудников.",
          );
        });
    }, 250);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [employeeQuery, formConfig?.employeePicker, itemTypeCode, pendingNewEmployee]);

  React.useEffect(() => {
    if (!orgScoped) return;
    if (orgUnitCatalogOptions.length === 0) return;

    const unitAllowed = isOrgUnitAllowedForGroup(
      selectedOrgUnitId ?? undefined,
      activeOrgGroupId ?? undefined,
      orgUnitCatalogOptions,
    );
    if (unitAllowed) return;

    setPayloadDraft((prev) => clearOrgDependentFields(prev, itemTypeCode));
  }, [orgScoped, activeOrgGroupId, selectedOrgUnitId, orgUnitCatalogOptions, itemTypeCode]);

  React.useEffect(() => {
    if (!orgScoped) return;

    const positionId = Number(selectedPositionIdFromDraft(payloadDraft, itemTypeCode));
    if (!Number.isFinite(positionId) || positionId <= 0) return;
    if (positionsLoading) return;
    if (isPositionAllowedInOptions(positionId, positionOptions)) return;

    setPayloadDraft((prev) => setPositionId(prev, itemTypeCode, ""));
  }, [orgScoped, positionOptions, positionsLoading, payloadDraft, itemTypeCode]);

  const formSignature = JSON.stringify({ itemTypeCode, employeeId, effectiveDate, payloadDraft });
  const hasUnsavedEdit = editingItemId != null && savedFormSignature.current != null && savedFormSignature.current !== formSignature;

  React.useEffect(() => {
    if (hasUnsavedEdit) setSaveNotice(null);
  }, [hasUnsavedEdit, formSignature]);

  function resetForm(typeCode: PersonnelOrderItemFormType = defaultItemType) {
    ++employeeSelectionRevision.current;
    setEditingItemId(null);
    setEditingItemSavedEmployeeId(null);
    setItemTypeCode(typeCode);
    setEmployeeId("");
    setEmployeeQuery("");
    setSelectedEmployeeId(null);
    setChangingEmployee(false);
    setPendingNewEmployee(false);
    setCurrentPlacement(null);
    setEffectiveDate("");
    setPayloadDraft(emptyItemPayloadDraft());
    setTerminationReasonSuggested(false);
    setEditingBasis(false);
    setTargetOrgGroupId(null);
    setHireOrgGroupId(null);
    setError(null);
    setSaveNotice(null);
    savedFormSignature.current = null;
  }

  async function applyEmployeeSelection(option: EmployeeSearchOption) {
    const selectionRevision = ++employeeSelectionRevision.current;
    ruGenitiveEdited.current = false;
    editedPositionForms.current.clear();
    setPendingNewEmployee(false);
    setEmployeeId(String(option.employee_id));
    setEmployeeQuery(option.full_name);
    setSelectedEmployeeId(option.employee_id);
    setEmployeeOptions([]);

    const config = getItemFormRegistry(itemTypeCode);
    if (config?.clearTargetOnEmployeeChange) {
      setPayloadDraft((prev) => clearTransferTargetFields(prev));
      setTargetOrgGroupId(null);
    }

    // A form belongs to its employee.  Clear all previous forms before the
    // asynchronous directory detail arrives so a prior employee cannot leak
    // into a new item.
    setPayloadDraft((prev) => ({
      ...prev,
      org_unit_document_genitive_kk: "",
      position_document_possessive_kk: "",
      employee_full_name_dative_kk: "",
      employee_full_name_genitive_kk: "",
      ...(itemTypeCode === "LEAVE.CHILDCARE.GRANT" ? { employee_full_name_dative_ru: "", employee_full_name_genitive_ru: "", position_document_nominative_ru: "" } : {}),
    }));
    setCalculatedKkFields(new Set());

    try {
      const details = await getEmployee(String(option.employee_id));
      if (selectionRevision !== employeeSelectionRevision.current) return;
      const selected = employeeDtoToSearchOption(details);
      const positionForms = resolvePersonnelOrderDocumentForms(details.position, details);
      const storedOrgUnitGenitive = String(details.org_unit?.document_genitive_kk || "").trim();
      const automaticOrgUnitGenitive = calculateKazakhOrgUnitGenitive(details.org_unit?.name_kk);
      const storedDative = explicitEmployeeKkNameForm(details, "employee_full_name_dative_kk");
      const storedGenitive = explicitEmployeeKkNameForm(details, "employee_full_name_genitive_kk");
      const automaticDative = calculateKazakhPersonForm(details, "dative");
      const automaticGenitive = calculateKazakhPersonForm(details, "genitive");
      const calculated = new Set<string>();
      if (!storedOrgUnitGenitive && automaticOrgUnitGenitive.value) calculated.add("org_unit_document_genitive_kk");
      if (!storedDative && automaticDative.value) calculated.add("employee_full_name_dative_kk");
      if (!storedGenitive && automaticGenitive.value) calculated.add("employee_full_name_genitive_kk");
      setCalculatedKkFields(calculated);
      setPayloadDraft((prev) => ({
        ...prev,
        org_unit_document_genitive_kk: editedPositionForms.current.has("org_unit_document_genitive_kk") ? prev.org_unit_document_genitive_kk : resolvePersonnelOrderOrgUnitForms(details.org_unit).org_unit_document_genitive_kk,
        position_document_possessive_kk: editedPositionForms.current.has("position_document_possessive_kk") ? prev.position_document_possessive_kk : positionForms.position_document_possessive_kk,
        employee_full_name_dative_kk: firstNonEmpty(storedDative, automaticDative.value),
        employee_full_name_genitive_kk: firstNonEmpty(storedGenitive, automaticGenitive.value),
        ...(itemTypeCode === "LEAVE.CHILDCARE.GRANT" ? { employee_full_name_dative_ru: savedRussianEmployeeNameForm(details, "dative"), employee_full_name_genitive_ru: ruGenitiveEdited.current ? prev.employee_full_name_genitive_ru : russianEmployeeGenitiveForOrder(details), position_document_nominative_ru: editedPositionForms.current.has("position_document_nominative_ru") ? prev.position_document_nominative_ru : positionForms.position_document_nominative_ru } : {}),
      }));
      if (config?.showCurrentPlacement) {
        setCurrentPlacement(await resolveCurrentPlacementView(selected));
      } else {
        setCurrentPlacement(null);
      }
    } catch {
      if (selectionRevision !== employeeSelectionRevision.current) return;
      // The picker already has an explicit selected employee.  A transient
      // detail request failure must not leave calculable name forms empty.
      const automaticDative = calculateKazakhPersonForm({ fio: option.full_name }, "dative");
      const automaticGenitive = calculateKazakhPersonForm({ fio: option.full_name }, "genitive");
      const calculated = new Set<string>();
      if (automaticDative.value) calculated.add("employee_full_name_dative_kk");
      if (automaticGenitive.value) calculated.add("employee_full_name_genitive_kk");
      setCalculatedKkFields(calculated);
      setPayloadDraft((prev) => ({
        ...prev,
        employee_full_name_dative_kk: automaticDative.value,
        employee_full_name_genitive_kk: automaticGenitive.value,
      }));
      setCurrentPlacement(null);
    }
  }

  async function loadCurrentPlacementByEmployeeId(id: number, fallbackName?: string | null) {
    try {
      const details = await getEmployee(String(id));
      const option = employeeDtoToSearchOption(details);
      if (!option.full_name && fallbackName) {
        option.full_name = fallbackName;
      }
      const placement = await resolveCurrentPlacementView(option);
      setCurrentPlacement(placement);
    } catch {
      setCurrentPlacement(null);
    }
  }

  async function startEdit(item: PersonnelOrderItem) {
    ++employeeSelectionRevision.current;
    const uiType = detectUiItemTypeFromRecord(item);
    const normalizedUiType = normalizeItemFormType(uiType) ?? defaultItemType;
    const draft = itemPayloadDraftFromRecord(item.payload);
    if (!draft.basis_entries?.length) {
      draft.basis_entries = (draft.basis_ids || []).map((basisId) => ({
        basis_id: basisId,
        document_type: String(basisDocuments.find((basis) => basis.basis_id === basisId)?.document_type || ""),
        other_text: "",
      }));
      if (draft.basis_other_text) {
        draft.basis_entries.push({ document_type: "OTHER", basis_id: "", other_text: draft.basis_other_text });
      }
    }
    const suggestedReason = normalizedUiType === "TERMINATION"
      && !String(draft.termination_reason || "").trim()
      && hasPersonalApplicationBasis(item.payload || {}, basisDocuments);
    if (suggestedReason) draft.termination_reason = "EMPLOYEE_INITIATIVE";
    const savedEmployeeId =
      item.employee_id != null && Number(item.employee_id) > 0 ? Number(item.employee_id) : null;
    setEditingItemId(item.item_id);
    setEditingItemSavedEmployeeId(savedEmployeeId);
    setItemTypeCode(normalizedUiType);
    setEmployeeId(item.employee_id ? String(item.employee_id) : "");
    setEmployeeQuery(item.employee_name || "");
    setSelectedEmployeeId(savedEmployeeId);
    setChangingEmployee(false);
    setPendingNewEmployee(
      savedEmployeeId == null && allowsPendingNewEmployee(normalizedUiType),
    );
    setEffectiveDate(persistedEffectiveDate(item));
    setPayloadDraft(draft);
    savedFormSignature.current = JSON.stringify({ itemTypeCode: normalizedUiType, employeeId: item.employee_id ? String(item.employee_id) : "", effectiveDate: persistedEffectiveDate(item), payloadDraft: draft });
    setTerminationReasonSuggested(suggestedReason);
    setEditingBasis(false);
    setError(null);
    setSaveNotice(null);
    setCurrentPlacement(null);

    const config = getItemFormRegistry(normalizedUiType);
    if (item.employee_id && config?.showCurrentPlacement) {
      void loadCurrentPlacementByEmployeeId(item.employee_id, item.employee_name);
    }

    const unitId = selectedOrgUnitIdFromDraft(draft, normalizedUiType);
    if (unitId == null) {
      setTargetOrgGroupId(null);
      setHireOrgGroupId(null);
      return;
    }
    try {
      const prefill = await resolveEmployeeOrgScopePrefill(unitId);
      if (config?.showHirePlacement) {
        setHireOrgGroupId(prefill.org_group_id);
      } else if (config?.showTargetPlacement) {
        setTargetOrgGroupId(prefill.org_group_id);
      }
    } catch {
      setTargetOrgGroupId(null);
      setHireOrgGroupId(null);
    }
  }

  function handleItemTypeChange(nextType: PersonnelOrderItemFormType) {
    ++employeeSelectionRevision.current;
    setItemTypeCode(nextType);
    setPayloadDraft(emptyItemPayloadDraft());
    setSelectedEmployeeId(null);
    setTerminationReasonSuggested(false);
    setEditingBasis(false);
    setTargetOrgGroupId(null);
    setHireOrgGroupId(null);
    setPendingNewEmployee(
      editingItemId != null &&
        editingItemSavedEmployeeId == null &&
        allowsPendingNewEmployee(nextType),
    );
    setError(null);
    if (!getItemFormRegistry(nextType)?.showCurrentPlacement) {
      setCurrentPlacement(null);
    }
  }

  function handlePendingNewEmployeeChange(checked: boolean) {
    if (savedEmployeeIdBlocksPendingReset) return;
    setPendingNewEmployee(checked);
    if (checked) {
      setEmployeeId("");
      setEmployeeQuery("");
      setEmployeeOptions([]);
      setCurrentPlacement(null);
    }
  }

  function updatePayloadField<K extends keyof ItemPayloadDraft>(key: K, value: string) {
    if (key === "position_document_possessive_kk" || key === "position_document_nominative_ru" || key === "org_unit_document_genitive_kk") editedPositionForms.current.add(key);
    if (key === "employee_full_name_genitive_ru") ruGenitiveEdited.current = true;
    setCalculatedKkFields((previous) => { const next = new Set(previous); next.delete(String(key)); return next; });
    setPayloadDraft((prev) => ({ ...prev, [key]: value }));
    if (key === "termination_reason") setTerminationReasonSuggested(false);
  }

  function handleTargetOrgGroupChange(nextGroupId: number | null) {
    setTargetOrgGroupId(nextGroupId);
    setPayloadDraft((prev) => clearOrgDependentFields(prev, itemTypeCode));
  }

  function handleHireOrgGroupChange(nextGroupId: number | null) {
    setHireOrgGroupId(nextGroupId);
    setPayloadDraft((prev) => clearOrgDependentFields(prev, "HIRE"));
  }

  function handleOrgUnitChange(nextUnitId: number | null) {
    setPayloadDraft((prev) => setOrgUnitAndClearPosition(prev, itemTypeCode, nextUnitId));
  }

  function handlePositionChange(nextPositionId: string) {
    setPayloadDraft((prev) => setPositionId(prev, itemTypeCode, nextPositionId));
  }

  function handleSubmit(e: React.FormEvent): Promise<boolean> {
    e.preventDefault();
    // The form button and beforeGenerate must await the same mutation.
    // React's `saving` state alone cannot guard callbacks in the same render.
    if (itemSaveInFlight.current) return itemSaveInFlight.current;
    const pending = saveItem();
    itemSaveInFlight.current = pending;
    void pending.finally(() => { itemSaveInFlight.current = null; });
    return pending;
  }

  async function saveItem(): Promise<boolean> {
    if (disabled) return false;
    setError(null);

    const employeeNumeric = Number(employeeId);
    const savedEmployeeIsUnchanged =
      editingItemId != null &&
      editingItemSavedEmployeeId != null &&
      Number.isFinite(employeeNumeric) &&
      employeeNumeric === editingItemSavedEmployeeId;
    const employeeRequiredMessage = savedEmployeeIsUnchanged
      ? null
      : requireEmployeeIdForItemType(itemTypeCode, employeeId, {
          pendingNewEmployee: pendingNewEmployee && pendingNewEmployeeAllowed,
          personId: payloadDraft.person_id,
        });
    if (employeeRequiredMessage) {
      setError(employeeRequiredMessage);
      return false;
    }
    if (
      !savedEmployeeIsUnchanged &&
      requiresEmployeeForFormType(itemTypeCode) &&
      !pendingNewEmployee &&
      selectedEmployeeId !== employeeNumeric
    ) {
      setError("Выберите действующего сотрудника из результатов поиска.");
      return false;
    }

    setSaving(true);
    try {
      const backendType = resolveBackendItemTypeCode(itemTypeCode);
      const isLeave = backendType === "LEAVE.ANNUAL.GRANT" || backendType === "LEAVE.UNPAID.GRANT" || backendType === "LEAVE.CHILDCARE.GRANT";
      const leaveStart = String(payloadDraft.leave_start || "").trim();
      const leaveEnd = String(payloadDraft.leave_end || "").trim();
      if (isLeave && (!leaveStart || !leaveEnd || !payloadDraft.application_date)) {
        setError("Для отпуска обязательны даты и дата личного заявления.");
        setSaving(false);
        return false;
      }
      if (isLeave && leaveEnd < leaveStart) {
        setError("Дата окончания отпуска не может быть раньше даты начала.");
        setSaving(false);
        return false;
      }
      let resolvedEmployeeId =
        Number.isFinite(employeeNumeric) && employeeNumeric > 0 ? employeeNumeric : null;
      if (savedEmployeeIdBlocksPendingReset && resolvedEmployeeId == null) {
        resolvedEmployeeId = editingItemSavedEmployeeId;
      }
      const savedItem = editingItemId == null ? null : items.find((item) => item.item_id === editingItemId);
      const savedPayload = savedItem?.payload || {};
      // Updating a form field must not erase imported context, placement,
      // basis ids, or other payload attributes not represented by inputs.
      const payload = { ...savedPayload, ...buildItemPayload(backendType, payloadDraft) };
      if (backendType === "LEAVE.UNPAID.GRANT") {
        // An edited legacy item must not carry its old triplet beside the
        // versioned `leave` object: the backend deliberately rejects two
        // conflicting period sources.
        delete payload.leave_start;
        delete payload.leave_end;
        delete payload.leave_days;
      }
      if (isLeave && currentPlacement) {
        payload.org_unit_name = currentPlacement.org_unit_name || null;
        payload.position_name = currentPlacement.position_name || null;
      }
      const body = {
        item_type_code: backendType,
        employee_id: resolvedEmployeeId,
        effective_date: isLeave ? leaveStart : effectiveDate || null,
        period_start: isLeave ? leaveStart : null,
        period_end: isLeave ? leaveEnd : null,
        payload,
      };
      const detail =
        editingItemId != null
          ? await updatePersonnelOrderItem(orderId, editingItemId, body)
          : await createPersonnelOrderItem(orderId, body);
      onChanged(detail);
      resetForm(itemTypeCode);
      if (editingItemId != null) setSaveNotice("Пункт сохранён. Сформируйте / обновите текст приказа.");
      return true;
    } catch (err) {
      const message = mapPersonnelOrdersApiError(err, "Не удалось сохранить пункт.");
      setError(/(?:CONTINUOUS_RANGE|SINGLE_DAY) leave\.days must equal inclusive range days/i.test(message)
        ? "Количество календарных дней отпуска должно совпадать с выбранным периодом включительно."
        : message);
      return false;
    } finally {
      setSaving(false);
    }
  }

  React.useEffect(() => {
    if (!registerPendingSave) return;
    registerPendingSave(() => {
      if (itemSaveInFlight.current) return itemSaveInFlight.current;
      if (editingItemId != null && !hasUnsavedEdit) return Promise.resolve(true);
      // The editor is rendered even before the operator starts a new item.
      // Generating text in that state must not attempt to save an empty
      // item (and, consequently, must not turn a normal generation into a
      // validation error). Only a changed existing item or a nonempty new
      // item needs the same submit path as the form.
      const meaningfulDraftFields: Array<keyof ItemPayloadDraft> = [
        "leave_start", "leave_end", "leave_days", "work_period_start", "work_period_end", "work_period_days",
        "application_date", "application_number", "vacation_benefit_rule", "leave_note",
        "birth_certificate_date", "birth_certificate_number", "employee_full_name_dative_ru", "employee_full_name_genitive_ru", "position_document_nominative_ru",
        "org_unit_document_genitive_kk", "position_document_possessive_kk",
        "employee_full_name_dative_kk", "employee_full_name_genitive_kk", "person_id", "org_unit_id",
        "position_id", "to_org_unit_id", "to_position_id", "to_rate", "termination_reason",
        "total_rate", "remaining_rate", "basis_id", "basis_other_text",
      ];
      const hasNewDraftValue =
        itemTypeCode !== defaultItemType ||
        Boolean(employeeId.trim() || employeeQuery.trim() || effectiveDate || pendingNewEmployee) ||
        meaningfulDraftFields.some((field) => String(payloadDraft[field] ?? "").trim().length > 0) ||
        Boolean(payloadDraft.vacation_benefit_applicable) ||
        Boolean(payloadDraft.basis_ids?.length || payloadDraft.basis_entries?.length) ||
        String(payloadDraft.employment_rate || "1") !== "1" ||
        String(payloadDraft.concurrent_rate || "0.5") !== "0.5";
      if (editingItemId == null && !hasNewDraftValue) return Promise.resolve(true);
      return handleSubmit({ preventDefault() {} } as React.FormEvent);
    });
    return () => registerPendingSave(null);
  });

  async function handleDeleteItem(item: PersonnelOrderItem) {
    if (disabled || item.item_status !== "ACTIVE" || deletionInProgressRef.current) return;
    if (!window.confirm(`Удалить пункт №${item.item_number}?`)) return;

    deletionInProgressRef.current = true;
    setDeletingItemId(item.item_id);
    setError(null);
    try {
      const detail = await deletePersonnelOrderItem(orderId, item.item_id);
      if (editingItemId === item.item_id) resetForm(itemTypeCode);
      onChanged(detail);
    } catch (err) {
      setError(mapPersonnelOrdersApiError(err, "Не удалось удалить пункт."));
    } finally {
      deletionInProgressRef.current = false;
      setDeletingItemId(null);
    }
  }

  function renderOrgPlacementCascade(options: {
    sectionTitle: string;
    orgGroupId: number | null;
    onOrgGroupChange: (id: number | null) => void;
    unitLabel: string;
    positionLabel: string;
    unitEmptyLabel: string;
    testId?: string;
  }) {
    const cascadeType = formConfig?.showHirePlacement ? "HIRE" : itemTypeCode;
    return (
      <div className="space-y-3" data-testid={options.testId ?? "personnel-order-org-placement"}>
        <div className="text-xs font-semibold uppercase tracking-wide text-zinc-500">
          {options.sectionTitle}
        </div>
        <div data-testid="personnel-order-org-scope-cascade">
          <OrgScopeFilter
            basePath={ORG_SCOPE_BASE_PATH}
            label="Группа отделений"
            value={options.orgGroupId}
            onChange={options.onOrgGroupChange}
          />
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <OrgUnitScopeFilter
              basePath={ORG_SCOPE_BASE_PATH}
              label={options.unitLabel}
              allLabel={options.unitEmptyLabel}
              orgGroupId={options.orgGroupId}
              value={selectedOrgUnitIdFromDraft(payloadDraft, cascadeType)}
              unitOptions={orgUnitSelectOptions}
              unitsLoading={orgUnitsLoading}
              unitsError={orgUnitsError}
              onChange={(unitId) => {
                if (formConfig?.showHirePlacement) {
                  setPayloadDraft((prev) => setOrgUnitAndClearPosition(prev, "HIRE", unitId));
                } else {
                  handleOrgUnitChange(unitId);
                }
              }}
            />
            <FormField label={options.positionLabel}>
              <select
                data-testid="personnel-order-position-select"
                value={selectedPositionIdFromDraft(payloadDraft, cascadeType)}
                onChange={(e) => {
                  if (formConfig?.showHirePlacement) {
                    setPayloadDraft((prev) => setPositionId(prev, "HIRE", e.target.value));
                  } else {
                    handlePositionChange(e.target.value);
                  }
                }}
                disabled={
                  selectedOrgUnitIdFromDraft(payloadDraft, cascadeType) == null ||
                  positionsLoading ||
                  positionOptions.length === 0
                }
                className={FIELD_INPUT_CLASS}
              >
                <option value="">
                  {selectedOrgUnitIdFromDraft(payloadDraft, cascadeType) == null
                    ? "Сначала выберите подразделение"
                    : positionsLoading
                      ? "Загрузка…"
                      : positionOptions.length === 0
                        ? "Нет доступных должностей"
                        : "—"}
                </option>
                {renderPersonnelOrderPositionOptions(positionGroups)}
              </select>
            </FormField>
          </div>
        </div>
      </div>
    );
  }

  function renderItemTypeSection() {
    return (
      <FormField
        label="Тип пункта"
        hint={
          orderTypeHint
            ? `Тип конкретной строки приказа. Тип приказа «${orderTypeHint}» задаётся в заголовке.`
            : "Тип конкретной строки приказа (в составных приказах пункты могут отличаться)."
        }
      >
        <select
          data-testid="personnel-order-item-type-select"
          value={itemTypeCode}
          onChange={(e) => handleItemTypeChange(e.target.value as PersonnelOrderItemFormType)}
          className={FIELD_INPUT_CLASS}
        >
          {itemTypeOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </FormField>
    );
  }

  function renderEmployeeSection() {
    if (!formConfig?.employeePicker) return null;

    const pendingAllowed = allowsPendingNewEmployee(itemTypeCode);

    return (
      <div className="space-y-3" data-testid="personnel-order-employee-section">
        {pendingAllowed ? (
          <div className="space-y-1">
            <label
              className={`flex items-start gap-2 text-sm ${
                pendingNewEmployeeAllowed
                  ? "text-zinc-700 dark:text-zinc-300"
                  : "text-zinc-500 dark:text-zinc-500"
              }`}
            >
              <input
                type="checkbox"
                checked={pendingNewEmployee}
                disabled={!pendingNewEmployeeAllowed}
                onChange={(e) => handlePendingNewEmployeeChange(e.target.checked)}
                data-testid="personnel-order-pending-new-employee"
                className="mt-0.5"
              />
              <span>
                <span className="font-medium">Новый сотрудник</span>
                <span
                  className="mt-0.5 block text-xs text-zinc-500"
                  data-testid={
                    savedEmployeeIdBlocksPendingReset
                      ? "personnel-order-pending-new-employee-reset-blocked"
                      : undefined
                  }
                >
                  {pendingNewEmployeeAllowed
                    ? `${HR_DOSSIER_TITLE} будет создана позже. Пункт сохранится без привязки к employee_id.`
                    : "Сброс сотрудника в сохранённом пункте пока не поддерживается."}
                </span>
              </span>
            </label>
          </div>
        ) : null}

        {savedEmployeeIdBlocksPendingReset && !changingEmployee ? (
          <div className="flex items-center justify-between gap-3 rounded-lg border border-zinc-200 px-3 py-2 dark:border-zinc-800" data-testid="personnel-order-linked-employee-card">
            <div className="min-w-0"><div className="truncate text-sm font-medium">{employeeQuery || "Сотрудник"}</div><div className="text-xs text-zinc-500">ID: {editingItemSavedEmployeeId}</div></div>
            <button type="button" className="shrink-0 text-sm font-medium text-blue-700 hover:underline dark:text-blue-300" onClick={() => { setChangingEmployee(true); setSelectedEmployeeId(null); setEmployeeOptions([]); }}>Сменить сотрудника</button>
          </div>
        ) : null}

        {showEmployeePicker ? (
          <FormField
            label="Сотрудник"
            hint={
              pendingAllowed && pendingNewEmployeeAllowed
                ? "Необязательно для приёма. Можно указать существующего сотрудника или оставить пустым."
                : "Выберите действующего сотрудника из результатов поиска."
            }
          >
            <div className="flex flex-wrap gap-2">
              <input
                value={employeeQuery}
                onChange={(e) => { setEmployeeQuery(e.target.value); setSelectedEmployeeId(null); }}
                placeholder="Поиск по ФИО…"
                autoComplete="off"
                data-testid="personnel-order-employee-search-input"
                className={`min-w-[12rem] flex-1 ${FIELD_INPUT_CLASS}`}
              />
              <input
                value={employeeId}
                onChange={(e) => { setEmployeeId(e.target.value); setSelectedEmployeeId(null); }}
                placeholder="ID"
                aria-label="Идентификатор сотрудника"
                data-testid="personnel-order-employee-id-input"
                className={`w-24 ${FIELD_INPUT_CLASS}`}
              />
            </div>
            {employeeSearchError ? (
              <p
                className="mt-1 text-xs text-red-600 dark:text-red-400"
                data-testid="personnel-order-employee-search-error"
              >
                {employeeSearchError}
              </p>
            ) : null}
            {employeeOptions.length > 0 ? (
              <div
                className="mt-1 max-h-32 overflow-auto rounded-lg border border-zinc-200 dark:border-zinc-800"
                data-testid="personnel-order-employee-search-results"
              >
                {employeeOptions.map((option) => (
                  <button
                    key={option.employee_id}
                    type="button"
                    className="block w-full px-3 py-1.5 text-left text-sm hover:bg-zinc-50 dark:hover:bg-zinc-900"
                    data-testid={`personnel-order-employee-option-${option.employee_id}`}
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => void applyEmployeeSelection(option)}
                  >
                    {option.full_name} · #{option.employee_id}
                  </button>
                ))}
              </div>
            ) : null}
          </FormField>
        ) : pendingNewEmployee ? (
          <p
            className="rounded-lg border border-dashed border-zinc-300 px-3 py-2 text-sm text-zinc-600 dark:border-zinc-700 dark:text-zinc-400"
            data-testid="personnel-order-pending-new-employee-hint"
          >
            {payloadDraft.person_id
              ? `Заявитель person #${payloadDraft.person_id}. Employee будет создан при проведении приказа.`
              : "Сотрудник не выбран. Укажите person_id заявителя или сохраните пункт из карточки заявителя."}
          </p>
        ) : null}
      </div>
    );
  }

  function renderEffectiveDateSection() {
    return (
      <FormField label={effectiveDateLabel}>
        <input
          type="date"
          value={effectiveDate}
          onChange={(e) => setEffectiveDate(e.target.value)}
          className={FIELD_INPUT_CLASS}
        />
      </FormField>
    );
  }

  function renderOrgPlacementSection() {
    if (formConfig?.showTargetPlacement) {
      return renderOrgPlacementCascade({
        sectionTitle: formConfig.orgPlacementSectionTitle,
        orgGroupId: targetOrgGroupId,
        onOrgGroupChange: handleTargetOrgGroupChange,
        unitLabel: "Подразделение",
        positionLabel: "Должность",
        unitEmptyLabel: "без изменения",
        testId: "personnel-order-target-placement",
      });
    }
    if (formConfig?.showHirePlacement) {
      return renderOrgPlacementCascade({
        sectionTitle: formConfig.orgPlacementSectionTitle,
        orgGroupId: hireOrgGroupId,
        onOrgGroupChange: handleHireOrgGroupChange,
        unitLabel: "Подразделение",
        positionLabel: "Должность",
        unitEmptyLabel: "Выберите подразделение",
        testId: "personnel-order-hire-legacy",
      });
    }
    return null;
  }

  function renderAdditionalSection() {
    if (itemTypeCode === "LEAVE.ANNUAL.GRANT" || itemTypeCode === "LEAVE.UNPAID.GRANT" || itemTypeCode === "LEAVE.CHILDCARE.GRANT") {
      const annual = itemTypeCode === "LEAVE.ANNUAL.GRANT";
      const childcare = itemTypeCode === "LEAVE.CHILDCARE.GRANT";
      const start = String(payloadDraft.leave_start || "");
      const end = String(payloadDraft.leave_end || "");
      const calculatedDays = start && end ? Math.max(0, Math.floor((Date.parse(`${end}T00:00:00`) - Date.parse(`${start}T00:00:00`)) / 86400000) + 1) : "";
      const kkUnpaidPreview = `${payloadDraft.org_unit_document_genitive_kk || "[бөлімше]"} ${payloadDraft.position_document_possessive_kk || "[лауазым]"} ${payloadDraft.employee_full_name_dative_kk || "[аты-жөні]"} ${unpaidPeriodClauseKk(payloadDraft)} еңбекақысы сақталмайтын демалыс берілсін. Негіз: ${payloadDraft.employee_full_name_genitive_kk || "[аты-жөні]"} жеке өтініші.`;
      return <div className="space-y-3" data-testid="personnel-leave-fields">
        <div className="grid gap-3 sm:grid-cols-3">
          <FormField label="Дата начала"><input type="date" data-testid="leave-start" value={start} onChange={(e) => annual ? updatePayloadField("leave_start", e.target.value) : setPayloadDraft((prev) => ({ ...prev, leave_start: e.target.value, leave_end: e.target.value }))} className={FIELD_INPUT_CLASS} /></FormField>
          <FormField label="Дата окончания"><input type="date" data-testid="leave-end" value={end} onChange={(e) => updatePayloadField("leave_end", e.target.value)} className={FIELD_INPUT_CLASS} /></FormField>
          <FormField label="Календарные дни"><input readOnly value={calculatedDays} data-testid="leave-days" className={FIELD_INPUT_CLASS} /></FormField>
        </div>
        {annual ? <div className="rounded-lg border border-zinc-200 p-3 dark:border-zinc-800" data-testid="annual-leave-work-periods">
          <div className="mb-2 flex items-center justify-between text-sm font-medium"><span>Рабочие периоды</span><button type="button" onClick={() => setPayloadDraft((prev) => { const periods = prev.work_periods?.length ? prev.work_periods : [{ start: prev.work_period_start || "", end: prev.work_period_end || "", days: prev.work_period_days || "" }]; return { ...prev, work_periods: [...periods, { start: "", end: "", days: "" }] }; })} className="text-blue-700 hover:underline">Добавить рабочий период</button></div>
          {(payloadDraft.work_periods || [{ start: payloadDraft.work_period_start || "", end: payloadDraft.work_period_end || "", days: payloadDraft.work_period_days || "" }]).map((period, index) => <div key={index} className="mb-3 grid gap-3 sm:grid-cols-4" data-testid={`annual-leave-work-period-${index}`}>
            <FormField label="Начало"><input type="date" value={period.start} onChange={(e) => setPayloadDraft((prev) => { const periods = prev.work_periods?.length ? prev.work_periods : [{ start: prev.work_period_start || "", end: prev.work_period_end || "", days: prev.work_period_days || "" }]; return {...prev, work_periods: periods.map((row, i) => i === index ? {...row, start:e.target.value} : row)}; })} className={FIELD_INPUT_CLASS} /></FormField>
            <FormField label="Окончание"><input type="date" value={period.end} onChange={(e) => setPayloadDraft((prev) => { const periods = prev.work_periods?.length ? prev.work_periods : [{ start: prev.work_period_start || "", end: prev.work_period_end || "", days: prev.work_period_days || "" }]; return {...prev, work_periods: periods.map((row, i) => i === index ? {...row, end:e.target.value} : row)}; })} className={FIELD_INPUT_CLASS} /></FormField>
            <FormField label="Дни за период"><input type="number" min="1" value={period.days} onChange={(e) => setPayloadDraft((prev) => { const periods = prev.work_periods?.length ? prev.work_periods : [{ start: prev.work_period_start || "", end: prev.work_period_end || "", days: prev.work_period_days || "" }]; return {...prev, work_periods: periods.map((row, i) => i === index ? {...row, days:e.target.value} : row)}; })} className={FIELD_INPUT_CLASS} /></FormField>
            {index > 0 ? <button type="button" onClick={() => setPayloadDraft((prev) => ({...prev, work_periods: (prev.work_periods || []).filter((_, i) => i !== index)}))} className="self-end rounded border px-2 py-2 text-sm">Удалить</button> : <span />}
          </div>)}
        </div> : null}
        <div className="grid gap-3 sm:grid-cols-2"><FormField label="Дата заявления"><input type="date" data-testid="leave-application-date" required value={payloadDraft.application_date || ""} onChange={(e) => updatePayloadField("application_date", e.target.value)} className={FIELD_INPUT_CLASS} /></FormField><FormField label="Номер заявления"><input value={payloadDraft.application_number || ""} onChange={(e) => updatePayloadField("application_number", e.target.value)} className={FIELD_INPUT_CLASS} /></FormField></div>
        {childcare ? <section className="grid gap-3 sm:grid-cols-2" data-testid="childcare-birth-certificate">
          <FormField label="Дата выдачи свидетельства о рождении"><input type="date" required value={payloadDraft.birth_certificate_date || ""} onChange={e => updatePayloadField("birth_certificate_date", e.target.value)} className={FIELD_INPUT_CLASS} /></FormField>
          <FormField label="Номер свидетельства о рождении"><input required value={payloadDraft.birth_certificate_number || ""} onChange={e => updatePayloadField("birth_certificate_number", e.target.value)} className={FIELD_INPUT_CLASS} /></FormField>
          <p className="text-xs sm:col-span-2">Дата выдачи свидетельства — не дата рождения ребёнка. Дата окончания отпуска вводится отдельно.</p>
          <FormField label="RU: ФИО (дательный падеж)"><input required value={payloadDraft.employee_full_name_dative_ru || ""} onChange={e => updatePayloadField("employee_full_name_dative_ru", e.target.value)} className={FIELD_INPUT_CLASS} /></FormField>
          <FormField label="RU: ФИО (родительный падеж)"><input required value={payloadDraft.employee_full_name_genitive_ru || ""} onChange={e => updatePayloadField("employee_full_name_genitive_ru", e.target.value)} className={FIELD_INPUT_CLASS} /></FormField>
          <FormField label="RU: должность (документная форма)"><input required value={payloadDraft.position_document_nominative_ru || ""} onChange={e => updatePayloadField("position_document_nominative_ru", e.target.value)} className={FIELD_INPUT_CLASS} /></FormField>
        </section> : null}
        {!annual ? <section className="grid gap-2 rounded-lg border border-zinc-200 p-3 sm:grid-cols-2 dark:border-zinc-800" data-testid="unpaid-leave-kk-document-forms">
          <FormField label="KK: бөлімше (ілік септік)"><input value={payloadDraft.org_unit_document_genitive_kk || ""} onChange={(e) => updatePayloadField("org_unit_document_genitive_kk", e.target.value)} className={FIELD_INPUT_CLASS} />{calculatedKkFields.has("org_unit_document_genitive_kk") ? <p className="mt-1 text-xs text-blue-700">Рассчитано автоматически. Проверьте.</p> : null}{!payloadDraft.org_unit_document_genitive_kk ? <p className="mt-1 text-xs text-amber-700 dark:text-amber-300" data-testid="personnel-order-org-unit-form-missing">В справочнике нет данных для расчёта формы подразделения. Заполните вручную.</p> : null}</FormField>
          <FormField label="KK: лауазым (құжат нысаны)"><input value={payloadDraft.position_document_possessive_kk || ""} onChange={(e) => updatePayloadField("position_document_possessive_kk", e.target.value)} className={FIELD_INPUT_CLASS} />{!payloadDraft.position_document_possessive_kk ? <p className="mt-1 text-xs text-amber-700 dark:text-amber-300" data-testid="personnel-order-position-form-missing">В справочнике должности нет казахского названия или документной формы. Заполните вручную.</p> : null}</FormField>
          <FormField label="KK: Т.А.Ә. (барыс септік)"><input value={payloadDraft.employee_full_name_dative_kk || ""} onChange={(e) => updatePayloadField("employee_full_name_dative_kk", e.target.value)} className={FIELD_INPUT_CLASS} />{calculatedKkFields.has("employee_full_name_dative_kk") ? <p className="mt-1 text-xs text-blue-700">Рассчитано автоматически. Проверьте.</p> : null}{!payloadDraft.employee_full_name_dative_kk ? <p className="mt-1 text-xs text-amber-700 dark:text-amber-300" data-testid="personnel-order-employee-dative-form-missing">Недостаточно данных для расчёта формы ФИО. Заполните вручную.</p> : null}</FormField>
          <FormField label="KK: Т.А.ӘА. (ілік септік)"><input value={payloadDraft.employee_full_name_genitive_kk || ""} onChange={(e) => updatePayloadField("employee_full_name_genitive_kk", e.target.value)} className={FIELD_INPUT_CLASS} />{calculatedKkFields.has("employee_full_name_genitive_kk") ? <p className="mt-1 text-xs text-blue-700">Рассчитано автоматически. Проверьте.</p> : null}{!payloadDraft.employee_full_name_genitive_kk ? <p className="mt-1 text-xs text-amber-700 dark:text-amber-300" data-testid="personnel-order-employee-genitive-form-missing">Недостаточно данных для расчёта формы ФИО. Заполните вручную.</p> : null}</FormField>
        </section> : null}
        {annual ? <><label className="flex gap-2 text-sm"><input type="checkbox" checked={Boolean(payloadDraft.vacation_benefit_applicable)} onChange={(e) => setPayloadDraft((prev) => ({...prev, vacation_benefit_applicable:e.target.checked}))} />Пособие к отпуску</label>{payloadDraft.vacation_benefit_applicable ? <FormField label="Правило пособия"><input value={payloadDraft.vacation_benefit_rule || ""} onChange={(e) => updatePayloadField("vacation_benefit_rule", e.target.value)} className={FIELD_INPUT_CLASS} /></FormField> : null}</> : null}
        <FormField label="Примечание"><textarea value={payloadDraft.leave_note || ""} onChange={(e) => updatePayloadField("leave_note", e.target.value)} className={FIELD_INPUT_CLASS} /></FormField>
        {!childcare ? <div className="rounded-lg border border-zinc-200 p-3 dark:border-zinc-800" data-testid="leave-order-preview">
          <div className="mb-2 flex gap-2"><button type="button" onClick={() => setLeavePreviewLocale("ru")} className={leavePreviewLocale === "ru" ? "font-semibold" : ""}>Русский</button><span>/</span><button type="button" onClick={() => setLeavePreviewLocale("kk")} className={leavePreviewLocale === "kk" ? "font-semibold" : ""}>Қазақша</button></div>
          <div className="text-sm font-semibold">{leavePreviewLocale === "ru" ? "ПРИКАЗ" : "БҰЙРЫҚ"}</div>
          <ol className="mt-2 list-decimal space-y-1 pl-5 text-sm"><li>{leavePreviewLocale === "ru" ? `${annual ? "Предоставить ежегодный трудовой отпуск" : "Предоставить отпуск без сохранения заработной платы"} ${employeeQuery || "сотруднику"}, ${currentPlacement?.position_name || "должность"} ${currentPlacement?.org_unit_name || "подразделения"}, с ${start || "…"} по ${end || "…"}, ${calculatedDays || "…"} календарных дней.` : annual ? `${employeeQuery || "Қызметкерге"} ${start || "…"} мен ${end || "…"} аралығында ${calculatedDays || "…"} күнтізбелік күнге жылдық ақылы еңбек демалысы берілсін.` : kkUnpaidPreview} {annual ? (payloadDraft.work_periods || []).map((p) => ` ${p.start}–${p.end}: ${p.days} ${leavePreviewLocale === "ru" ? "дн." : "күн."}`).join("") : ""} {payloadDraft.vacation_benefit_applicable ? (leavePreviewLocale === "ru" ? ` Пособие: ${payloadDraft.vacation_benefit_rule || "…"}.` : ` Демалыс жәрдемақысы: ${payloadDraft.vacation_benefit_rule || "…"}.`) : ""} {annual ? (leavePreviewLocale === "ru" ? ` Основание: личное заявление от ${payloadDraft.application_date || "…"}.` : ` Негіз: ${payloadDraft.application_date || "…"} күнгі жеке өтініш.`) : ""}</li></ol>
        </div> : <p className="text-xs">Текст RU/KK с двумя основаниями формируется из сохранённых реквизитов по шаблону отпуска по уходу за ребёнком.</p>}
      </div>;
    }
    return (
      <div className="grid gap-3 sm:grid-cols-2">
        {formConfig?.showTargetRate && formConfig.showTargetPlacement ? (
          <FormField label="Новая ставка">
            <input
              data-testid="personnel-order-target-rate-input"
              value={payloadDraft.to_rate || ""}
              onChange={(e) => updatePayloadField("to_rate", e.target.value)}
              className={FIELD_INPUT_CLASS}
            />
          </FormField>
        ) : null}

        {formConfig?.showTargetRate && !formConfig.showTargetPlacement ? (
          <FormField label="Новая ставка" className="sm:col-span-2">
            <input
              data-testid="personnel-order-new-rate-input"
              value={payloadDraft.to_rate || ""}
              onChange={(e) => updatePayloadField("to_rate", e.target.value)}
              className={FIELD_INPUT_CLASS}
            />
          </FormField>
        ) : null}

        {formConfig?.showHirePlacement ? (
          <FormField label="Ставка" className="sm:col-span-2">
            <input
              data-testid="personnel-order-hire-rate-input"
              value={payloadDraft.employment_rate || ""}
              onChange={(e) => updatePayloadField("employment_rate", e.target.value)}
              className={FIELD_INPUT_CLASS}
            />
          </FormField>
        ) : null}

        {formConfig?.showTerminationReason ? (
          <FormField label="Причина увольнения" className="sm:col-span-2">
              <select
                data-testid="personnel-order-termination-reason-input"
                value={payloadDraft.termination_reason || ""}
                onChange={(e) => updatePayloadField("termination_reason", e.target.value)}
                className={FIELD_INPUT_CLASS}
              >
                <option value="">Выберите причину</option>
                <option value="EMPLOYEE_INITIATIVE">по инициативе работника / жұмыскердің бастамасы бойынша</option>
              </select>
              {terminationReasonSuggested ? <p className={FIELD_HINT_CLASS} data-testid="personnel-order-termination-reason-suggestion">Определено по основанию: личное заявление работника</p> : null}
          </FormField>
        ) : null}

        {formConfig?.showConcurrentDutyStartFields ? (
          <>
            <FormField label="Ставка совмещения">
              <input
                value={payloadDraft.concurrent_rate || ""}
                onChange={(e) => updatePayloadField("concurrent_rate", e.target.value)}
                className={FIELD_INPUT_CLASS}
              />
            </FormField>
            <FormField label="Итоговая ставка">
              <input
                value={payloadDraft.total_rate || ""}
                onChange={(e) => updatePayloadField("total_rate", e.target.value)}
                className={FIELD_INPUT_CLASS}
              />
            </FormField>
          </>
        ) : null}

        {formConfig?.showConcurrentDutyEndFields ? (
          <>
            <FormField label="Остающаяся ставка">
              <input
                value={payloadDraft.remaining_rate || ""}
                onChange={(e) => updatePayloadField("remaining_rate", e.target.value)}
                className={FIELD_INPUT_CLASS}
              />
            </FormField>
            <FormField label="Снимаемая ставка">
              <input
                value={payloadDraft.concurrent_rate || ""}
                onChange={(e) => updatePayloadField("concurrent_rate", e.target.value)}
                className={FIELD_INPUT_CLASS}
              />
            </FormField>
          </>
        ) : null}
      </div>
    );
  }

  function renderBasisDocumentSection() {
    const entries = payloadDraft.basis_entries || [];
    const basisTypes = Array.from(new Set(basisDocuments
      .map((basis) => typeof basis.document_type === "string" ? basis.document_type : "")
      .filter(Boolean)));
    const updateEntry = (index: number, next: Partial<{ document_type: string; basis_id: string; other_text: string }>) => {
      setPayloadDraft((previous) => ({
        ...previous,
        basis_entries: (previous.basis_entries || []).map((entry, entryIndex) => entryIndex === index ? { ...entry, ...next } : entry),
      }));
    };
    if (editingItemId != null && entries.length > 0 && !editingBasis) {
      return <div className="rounded-lg border border-zinc-200 p-3 dark:border-zinc-800" data-testid="personnel-order-basis-compact">
        <div className="flex items-center justify-between gap-3"><div className="text-sm font-medium">Основание</div><button type="button" className="text-sm font-medium text-blue-700 hover:underline dark:text-blue-300" onClick={() => setEditingBasis(true)}>Изменить основание</button></div>
        <div className="mt-2 space-y-2 text-sm">{entries.map((entry, index) => {
          const linked = basisDocuments.find((document) => String(document.basis_id || "") === entry.basis_id);
          const description = linked?.description && typeof linked.description === "object" ? linked.description as Record<string, unknown> : {};
          const linkedLabel = typeof description.ru === "string" ? description.ru : typeof description.kk === "string" ? description.kk : entry.basis_id;
          return <div key={index} className="rounded bg-zinc-50 px-2 py-1.5 dark:bg-zinc-900/50"><span className="font-medium">{basisTypeLabel(entry.document_type)}</span>{linkedLabel ? <span className="text-zinc-600 dark:text-zinc-300"> · {linkedLabel}</span> : null}{entry.other_text ? <span className="text-zinc-600 dark:text-zinc-300"> · {entry.other_text}</span> : null}</div>;
        })}</div>
      </div>;
    }
    return (
      <div className="space-y-3 rounded-lg border border-zinc-200 p-3 dark:border-zinc-800" data-testid="personnel-order-basis-selector">
        <div className="text-sm font-medium">Основания</div>
        {entries.map((entry, index) => {
          const matchingDocuments = basisDocuments.filter((basis) => basis.document_type === entry.document_type);
          return (
            <div key={index} className="grid gap-3 rounded border border-zinc-200 p-3 dark:border-zinc-800" data-testid={`personnel-order-basis-entry-${index}`}>
              <FormField label="Вид основания">
                <select value={entry.document_type} onChange={(e) => updateEntry(index, { document_type: e.target.value, basis_id: "", other_text: "" })} className={FIELD_INPUT_CLASS}>
                  <option value="">Не выбрано</option>
                  {basisTypes.map((documentType) => <option key={documentType} value={documentType}>{basisTypeLabel(documentType)}</option>)}
                  <option value="OTHER">Другое</option>
                </select>
              </FormField>
              {entry.document_type && entry.document_type !== "OTHER" ? (
                <FormField label="Связанный документ">
                  <select value={entry.basis_id} onChange={(e) => updateEntry(index, { basis_id: e.target.value })} className={FIELD_INPUT_CLASS}>
                    <option value="">Не выбрано</option>
                    {matchingDocuments.map((basis, basisIndex) => {
                      const basisId = typeof basis.basis_id === "string" ? basis.basis_id : "";
                      const description = basis.description && typeof basis.description === "object" ? basis.description as Record<string, unknown> : {};
                      const label = typeof description.kk === "string" ? description.kk : typeof description.ru === "string" ? description.ru : basisId;
                      return basisId ? <option key={basisId || basisIndex} value={basisId}>{label}</option> : null;
                    })}
                  </select>
                </FormField>
              ) : null}
              {entry.document_type === "OTHER" ? <FormField label="Текст основания"><textarea value={entry.other_text} onChange={(e) => updateEntry(index, { other_text: e.target.value })} className={FIELD_INPUT_CLASS} /></FormField> : null}
              {entries.length > 1 ? <button type="button" onClick={() => setPayloadDraft((previous) => ({ ...previous, basis_entries: (previous.basis_entries || []).filter((_, entryIndex) => entryIndex !== index) }))} className="justify-self-start text-xs text-red-700 hover:underline dark:text-red-300">Удалить основание</button> : null}
            </div>
          );
        })}
        <button type="button" onClick={() => setPayloadDraft((previous) => ({ ...previous, basis_entries: [...(previous.basis_entries || []), { document_type: "", basis_id: "", other_text: "" }] }))} className="text-sm font-medium text-blue-700 hover:underline dark:text-blue-300">Добавить основание</button>
        <p className={FIELD_HINT_CLASS}>Исходный текст импортированного основания не изменяется автоматически.</p>
      </div>
    );
  }

  function renderFormSection(section: ItemFormSection) {
    switch (section) {
      case "item_type":
        return <React.Fragment key={section}>{renderItemTypeSection()}</React.Fragment>;
      case "employee":
        return <React.Fragment key={section}>{renderEmployeeSection()}</React.Fragment>;
      case "current_placement":
        return formConfig?.showCurrentPlacement && currentPlacement ? (
          <CurrentPlacementPanel key={section} placement={currentPlacement} />
        ) : null;
      case "org_placement":
        return <React.Fragment key={section}>{renderOrgPlacementSection()}</React.Fragment>;
      case "effective_date":
        return <React.Fragment key={section}>{renderEffectiveDateSection()}</React.Fragment>;
      case "additional": {
        const additional = renderAdditionalSection();
        return additional ? <React.Fragment key={section}>{additional}</React.Fragment> : null;
      }
      default:
        return null;
    }
  }

  const sectionOrder = formConfig?.fieldSectionOrder ?? [];

  return (
    <div className="space-y-4" data-testid="personnel-order-item-editor">
      <div className="overflow-x-auto rounded-xl border border-zinc-200 dark:border-zinc-800">
        <table className="min-w-full text-sm">
          <thead className="bg-zinc-50 dark:bg-zinc-900/50">
            <tr>
              {["№", "Тип пункта", "Сотрудник", "Дата", "Основные данные", "Статус", ""].map((h) => (
                <th
                  key={h || "actions"}
                  className="px-3 py-2 text-left text-[11px] font-semibold uppercase text-zinc-500"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
            {items.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-3 py-3 text-sm text-zinc-500">
                  Пункты отсутствуют.
                </td>
              </tr>
            ) : (
              items.map((item) => (
                <tr key={item.item_id}>
                  <td className="px-3 py-2">{item.item_number}</td>
                  <td className="px-3 py-2">
                    {itemFormTypeLabel(detectUiItemTypeFromRecord(item))}
                  </td>
                  <td className="px-3 py-2">
                    {sourceEmployeeName(item)}
                  </td>
                  <td className="px-3 py-2">{item.effective_date || "—"}</td>
                  <td className="max-w-[24rem] px-3 py-2 text-zinc-700 dark:text-zinc-300">
                    {sourceItemSummary(item)}
                  </td>
                  <td className="px-3 py-2">{item.item_status}</td>
                  <td className="px-3 py-2">
                    {!disabled && item.item_status === "ACTIVE" ? (
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          className="text-xs font-medium text-blue-700 hover:underline dark:text-blue-300"
                          onClick={() => void startEdit(item)}
                          disabled={saving || deletingItemId === item.item_id}
                        >
                          Редактировать
                        </button>
                        <button
                          type="button"
                          className="text-xs font-medium text-red-700 hover:underline disabled:opacity-50 dark:text-red-300"
                          onClick={() => void handleDeleteItem(item)}
                          disabled={saving || deletingItemId != null}
                          data-testid={`personnel-order-item-delete-${item.item_id}`}
                        >
                          {deletingItemId === item.item_id ? "Удаление…" : "Удалить"}
                        </button>
                      </div>
                    ) : null}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {!disabled ? (
        <form
          className="space-y-4 rounded-xl border border-zinc-200 p-4 dark:border-zinc-800"
          onSubmit={handleSubmit}
        >
          <div>
            <div className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
              {editingItemId != null ? `Редактирование пункта #${editingItemId}` : "Добавить пункт"}
            </div>
            <p className="mt-1 text-xs text-zinc-500">
              Заполните поля пункта в указанном порядке. Тип пункта не заменяет тип приказа.
            </p>
          </div>

          <fieldset disabled={saving} className="space-y-4">
            {sectionOrder.map((section) => renderFormSection(section))}
          </fieldset>

          {error ? (
            <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800 dark:border-red-900/55 dark:bg-red-950/35 dark:text-red-200">
              {error}
            </div>
          ) : null}

          <div className="flex flex-wrap gap-2">
            <button
              type="submit"
              disabled={saving}
              className="rounded-lg bg-zinc-900 px-3 py-2 text-sm font-medium text-white disabled:opacity-60 dark:bg-zinc-100 dark:text-zinc-900"
            >
              {saving ? "Сохранение…" : editingItemId != null ? "Сохранить пункт" : "Добавить пункт"}
            </button>
            {hasUnsavedEdit ? <span className="self-center text-sm text-amber-700">Есть несохранённые изменения</span> : null}
            {saveNotice ? <span role="status" className="self-center text-sm text-emerald-700">{saveNotice}</span> : null}
            {editingItemId != null ? (
              <button
                type="button"
                onClick={() => resetForm(defaultItemType)}
                disabled={saving}
                className="rounded-lg border border-zinc-300 px-3 py-2 text-sm dark:border-zinc-700"
              >
                Отмена
              </button>
            ) : null}
          </div>
        </form>
      ) : null}
    </div>
  );
}
